﻿#define AppVer GetFileVersion('libkiclient.exe')
#define ProfileGuid '5857eb3f-b8d0-42c5-8cdd-c6910a13f317'

[Setup]
AppName=Libki Kiosk Management System Client
AppVersion={#AppVer}
AppPublisher=Kyle M Hall
AppPublisherURL=http://kylehall.info/
AppSupportURL=http://libki.org/
AppUpdatesURL=http://libki.org/
; Qt6-Build ist reines 64-Bit (mingw_64). Erzwingt 64-Bit-Installationsmodus,
; wodurch {pf}/{commonpf} automatisch auf das echte 64-Bit-Programme-
; Verzeichnis zeigt (statt "Programme (x86)").
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
DefaultDirName={autopf}\Libki
DefaultGroupName=Libki Client
OutputBaseFilename=Libki_Client_Installer
Compression=lzma
AllowNoIcons=yes
; Sprache automatisch anhand der Windows-UI-Sprache wählen, ohne Dialog.
ShowLanguageDialog=no
LanguageDetectionMethod=uilanguage

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "german"; MessagesFile: "compiler:Languages\German.isl"

[Files]
Source: "libkiclient.exe"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0

Source: "windows\on_login.exe"; DestDir: "{app}\windows"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "windows\on_logout.exe"; DestDir: "{app}\windows"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "windows\on_startup.exe"; DestDir: "{app}\windows"; Flags: ignoreversion; MinVersion: 0.0,5.0

Source: "clawPDF\clawPDF4Libki.ini"; DestDir: "{app}\windows"; Flags: ignoreversion; MinVersion: 0.0,5.0

Source: "C:\Qt6\6.11.1\mingw_64\plugins\generic\qtuiotouchplugin.dll"; DestDir: "{app}\generic"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\iconengines\qsvgicon.dll"; DestDir: "{app}\iconengines"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\imageformats\qgif.dll"; DestDir: "{app}\imageformats"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\imageformats\qico.dll"; DestDir: "{app}\imageformats"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\imageformats\qjpeg.dll"; DestDir: "{app}\imageformats"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\imageformats\qsvg.dll"; DestDir: "{app}\imageformats"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\networkinformation\qnetworklistmanager.dll"; DestDir: "{app}\networkinformation"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\platforms\qwindows.dll"; DestDir: "{app}\platforms"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\styles\qmodernwindowsstyle.dll"; DestDir: "{app}\styles"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\tls\qcertonlybackend.dll"; DestDir: "{app}\tls"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\plugins\tls\qschannelbackend.dll"; DestDir: "{app}\tls"; Flags: ignoreversion; MinVersion: 0.0,5.0

Source: "C:\Qt6\6.11.1\mingw_64\bin\d3dcompiler_47.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\libgcc_s_seh-1.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\libstdc++-6.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\libwinpthread-1.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\opengl32sw.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\Qt6Core.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\Qt6Gui.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\Qt6Network.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\Qt6Svg.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0
Source: "C:\Qt6\6.11.1\mingw_64\bin\Qt6Widgets.dll"; DestDir: "{app}"; Flags: ignoreversion; MinVersion: 0.0,5.0

[Registry]
Root: "HKLM"; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: String; ValueName: "Libki"; ValueData: "{app}\libkiclient.exe"; Flags: createvalueifdoesntexist uninsdeletekey; MinVersion: 0.0,5.0; Check: CheckStartAfterShell
Root: "HKLM32"; Subkey: "Software\Microsoft\Windows NT\CurrentVersion\Winlogon"; ValueType: String; ValueName: "Shell"; ValueData: "{app}\libkiclient.exe"; MinVersion: 0.0,5.0; Check: CheckShellReplacement and not isWin64
Root: "HKLM64"; Subkey: "Software\Microsoft\Windows NT\CurrentVersion\Winlogon"; ValueType: String; ValueName: "Shell"; ValueData: "{app}\libkiclient.exe"; MinVersion: 0.0,5.0; Check: CheckShellReplacement and IsWin64
Root: "HKLM"; Subkey: "Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize"; ValueType: Dword; ValueName: "StartupDelayInMSec"; ValueData: "0"; MinVersion: 0.0,5.0;

[CustomMessages]
english.NameAndVersion=%1 version %2
german.NameAndVersion=%1 Version %2
english.AdditionalIcons=Additional icons:
german.AdditionalIcons=Zusätzliche Symbole:
english.CreateDesktopIcon=Create a &desktop icon
german.CreateDesktopIcon=&Desktopsymbol erstellen
english.CreateQuickLaunchIcon=Create a &Quick Launch icon
german.CreateQuickLaunchIcon=Symbol in der &Schnellstartleiste erstellen
english.ProgramOnTheWeb=%1 on the Web
german.ProgramOnTheWeb=%1 im Web
english.UninstallProgram=Uninstall %1
german.UninstallProgram=%1 deinstallieren
english.LaunchProgram=Launch %1
german.LaunchProgram=%1 starten
english.AssocFileExtension=&Associate %1 with the %2 file extension
german.AssocFileExtension=%1 mit der Dateiendung %2 &verknüpfen
english.AssocingFileExtension=Associating %1 with the %2 file extension...
german.AssocingFileExtension=%1 wird mit der Dateiendung %2 verknüpft...

; Server Information page
english.ServerPageCaption=Server Information
german.ServerPageCaption=Serverinformationen
english.ServerPageDescription=Libki server data
german.ServerPageDescription=Libki-Serverdaten
english.ServerPageSubCaption=Please specify the Libki server data.
german.ServerPageSubCaption=Bitte geben Sie die Libki-Serverdaten an.
english.ServerFieldScheme=Scheme:
german.ServerFieldScheme=Schema:
english.ServerFieldHost=Host:
german.ServerFieldHost=Host:
english.ServerFieldPort=Port:
german.ServerFieldPort=Port:

; Client Information page
english.ClientPageCaption=Client Information
german.ClientPageCaption=Client-Informationen
english.ClientPageDescription=Libki client data
german.ClientPageDescription=Libki-Client-Daten
english.ClientPageSubCaption=Please specify the Libki client data.
german.ClientPageSubCaption=Bitte geben Sie die Libki-Client-Daten an.
english.ClientFieldLocation=Location:
german.ClientFieldLocation=Standort:
english.ClientFieldRunOnly=Run only for this user:
german.ClientFieldRunOnly=Nur für diesen Benutzer ausführen:
english.ClientFieldStopOnly=Run for all users but this one:
german.ClientFieldStopOnly=Für alle Benutzer außer diesem ausführen:
english.ClientFieldName=Client name:
german.ClientFieldName=Client-Name:

; Startup mode page
english.StartupPageCaption=Startup mode
german.StartupPageCaption=Startmodus
english.StartupPageDescription=Specify how to start the client
german.StartupPageDescription=Startverhalten des Clients festlegen
english.StartupPageSubCaption=Please specify how the Libki client should be started
german.StartupPageSubCaption=Bitte legen Sie fest, wie der Libki-Client gestartet werden soll.
english.StartupOptionAfterShell=Automatically start Libki client after normal user shell
german.StartupOptionAfterShell=Libki-Client automatisch nach der normalen Benutzer-Shell starten
english.StartupOptionReplaceShell=Automatically start Libki instead of user shell (shell replacement)
german.StartupOptionReplaceShell=Libki automatisch anstelle der Benutzer-Shell starten (Shell-Ersatz)
english.StartupOptionNone=Do not start Libki client automatically
german.StartupOptionNone=Libki-Client nicht automatisch starten

; Logout Action page
english.LogoutPageCaption=Logout Action
german.LogoutPageCaption=Abmeldeaktion
english.LogoutPageDescription=Specify action on logout?
german.LogoutPageDescription=Aktion bei Abmeldung festlegen
english.LogoutPageSubCaption=Please specify how the Libki client should act on logout.
german.LogoutPageSubCaption=Bitte legen Sie fest, wie sich der Libki-Client bei der Abmeldung verhalten soll.
english.LogoutOptionReboot=Reboot (best for Deep Freeze)
german.LogoutOptionReboot=Neustart (am besten für Deep Freeze geeignet)
english.LogoutOptionLogout=Log out of operating system (best for Clean Slate)
german.LogoutOptionLogout=Vom Betriebssystem abmelden (am besten für Clean Slate geeignet)
english.LogoutOptionNone=Nothing (just redisplay the Libki login screen)
german.LogoutOptionNone=Nichts (nur den Libki-Anmeldebildschirm erneut anzeigen)

; Client Disable page
english.PasswordPageCaption=Client Disable
german.PasswordPageCaption=Client deaktivieren
english.PasswordPageDescription=Libki client disabling password
german.PasswordPageDescription=Passwort zum Deaktivieren des Libki-Clients
english.PasswordPageSubCaption=Please specify the password for disabling the Libki client.
german.PasswordPageSubCaption=Bitte legen Sie das Passwort zum Deaktivieren des Libki-Clients fest.
english.PasswordFieldPassword=Password:
german.PasswordFieldPassword=Passwort:

; Printer Configuration page
english.PrintersPageCaption=Printer Configuration
german.PrintersPageCaption=Druckerkonfiguration
english.PrintersPageDescription=List the printers you wish to install on this Client, one per line, or leave blank to skip printer installation
german.PrintersPageDescription=Listen Sie die auf diesem Client zu installierenden Drucker auf, einen pro Zeile, oder lassen Sie das Feld leer, um die Druckerinstallation zu überspringen.

; Error messages
english.InvalidPrinterNames=The following printer names are invalid for YAML keys:
german.InvalidPrinterNames=Die folgenden Druckernamen sind als YAML-Schlüssel ungültig:
english.InvalidPrinterNamesHint=Names must start with a letter and contain only letters, numbers, _ or -.
german.InvalidPrinterNamesHint=Namen müssen mit einem Buchstaben beginnen und dürfen nur Buchstaben, Zahlen, _ oder - enthalten.
english.ClawPDFImportFailed=Could not import configs
german.ClawPDFImportFailed=Konfiguration konnte nicht importiert werden
english.ClawPDFNotFound=clawPDF executable not found at
german.ClawPDFNotFound=clawPDF-Programmdatei nicht gefunden unter

[INI]
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "server"; Key: "host"; String: "{code:GetHost}"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "server"; Key: "port"; String: "{code:GetPort}"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "server"; Key: "scheme"; String: "{code:GetScheme}"

Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "windows"; Key: "EnableStartButton"; String: "1"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "start_user_shell"; String: "C:\Windows\explorer.exe"; Check: CheckShellReplacement
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "logoutAction"; String: "{code:GetLogoutAction}"
;logout, reboot, noaction
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "onlyStopFor"; String: "{code:GetOnlyStopFor}"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "onlyRunFor"; String: "{code:GetOnlyRunFor}"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "location"; String: "{code:GetLocation}"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "password"; String: "{code:GetPassword}"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "username"; String: "Username or library card number"
Filename: "{commonappdata}\Libki\Libki Kiosk Management System.ini"; Section: "node"; Key: "name"; String: "{code:GetNodeName}"

[Code]
var
  ServerPage: TInputQueryWizardPage;
  ClientPage: TInputQueryWizardPage;
  StartupModePage: TInputOptionWizardPage;
  RebootActionPage: TInputOptionWizardPage;
  PasswordPage: TInputQueryWizardPage;
  PrintersPage: TWizardPage;
  PrintersMemo: TNewMemo;

{ Regex helper }
function IsYamlSafeKey(const S: String): Boolean;
var
  i: Integer;
  C: Char;
begin
  Result := False;

  if Length(S) = 0 then Exit;

  { Must start with a letter }
  C := S[1];
  if not (
    ((C >= 'A') and (C <= 'Z')) or
    ((C >= 'a') and (C <= 'z'))
  ) then Exit;

  { Remaining characters }
  for i := 2 to Length(S) do
  begin
    C := S[i];
    if not (
      ((C >= 'A') and (C <= 'Z')) or
      ((C >= 'a') and (C <= 'z')) or
      ((C >= '0') and (C <= '9')) or
      (C = '_') or
      (C = '-')
    ) then Exit;
  end;

  Result := True;
end;

procedure InitializeWizard;
begin
  { Create the pages }
  
  ServerPage := CreateInputQueryPage(wpWelcome,
    CustomMessage('ServerPageCaption'), CustomMessage('ServerPageDescription'),
    CustomMessage('ServerPageSubCaption'));
  ServerPage.Add(CustomMessage('ServerFieldScheme'), False);
  ServerPage.Add(CustomMessage('ServerFieldHost'), False);
  ServerPage.Add(CustomMessage('ServerFieldPort'), False);

  ClientPage := CreateInputQueryPage(ServerPage.ID,
    CustomMessage('ClientPageCaption'), CustomMessage('ClientPageDescription'),
    CustomMessage('ClientPageSubCaption'));
  ClientPage.Add(CustomMessage('ClientFieldLocation'), False);
  ClientPage.Add(CustomMessage('ClientFieldRunOnly'), False);
  ClientPage.Add(CustomMessage('ClientFieldStopOnly'), False);
  ClientPage.Add(CustomMessage('ClientFieldName'), False);

  StartupModePage := CreateInputOptionPage(ClientPage.ID,
    CustomMessage('StartupPageCaption'), CustomMessage('StartupPageDescription'),
    CustomMessage('StartupPageSubCaption'),
    True, False);
  StartupModePage.Add(CustomMessage('StartupOptionAfterShell'));
  StartupModePage.Add(CustomMessage('StartupOptionReplaceShell'));
  StartupModePage.Add(CustomMessage('StartupOptionNone'));
  StartupModePage.SelectedValueIndex := 0;

  RebootActionPage := CreateInputOptionPage(StartupModePage.ID,
    CustomMessage('LogoutPageCaption'), CustomMessage('LogoutPageDescription'),
    CustomMessage('LogoutPageSubCaption'),
    True, False);
  RebootActionPage.Add(CustomMessage('LogoutOptionReboot'));
  RebootActionPage.Add(CustomMessage('LogoutOptionLogout'));
  RebootActionPage.Add(CustomMessage('LogoutOptionNone'));

  PasswordPage := CreateInputQueryPage(RebootActionPage.ID,
    CustomMessage('PasswordPageCaption'), CustomMessage('PasswordPageDescription'),
    CustomMessage('PasswordPageSubCaption'));
  PasswordPage.Add(CustomMessage('PasswordFieldPassword'), True);
  
  PrintersPage := CreateCustomPage(
    PasswordPage.ID,
    CustomMessage('PrintersPageCaption'),
    CustomMessage('PrintersPageDescription')
  );

  PrintersMemo := TNewMemo.Create(PrintersPage);
  PrintersMemo.Parent := PrintersPage.Surface;
  PrintersMemo.Left := ScaleX(0);
  PrintersMemo.Top := ScaleY(0);
  PrintersMemo.Width := PrintersPage.SurfaceWidth;
  PrintersMemo.Height := PrintersPage.SurfaceHeight;
  PrintersMemo.ScrollBars := ssVertical;
  PrintersMemo.WordWrap := False;
  PrintersMemo.WantReturns := True;

  { Set default values, using settings that were stored last time if possible }


  { Read command line parameters and set them as default values for installer UI pages. }
  ServerPage.Values[0] := ExpandConstant('{param:scheme|}');
  ServerPage.Values[1] := ExpandConstant('{param:host|}');
  ServerPage.Values[2] := ExpandConstant('{param:port|}');
  ClientPage.Values[0] := ExpandConstant('{param:location|}');
  ClientPage.Values[1] := ExpandConstant('{param:runonly|}');
  ClientPage.Values[2] := ExpandConstant('{param:stoponly|}');
  ClientPage.Values[3] := ExpandConstant('{param:nodename|}');
  PasswordPage.Values[0] := ExpandConstant('{param:password|}');

  { Parse RebootAction string. Can be one of 'reboot', 'logout', or 'none'. Defaults to 'reboot' }
  if CompareText(ExpandConstant('{param:rebootaction}'), 'logout') = 0 then
    RebootActionPage.SelectedValueIndex := 1
  else if CompareText(ExpandConstant('{param:rebootaction}'), 'none') = 0 then
    RebootActionPage.SelectedValueIndex := 2
  else
    RebootActionPage.SelectedValueIndex := 0;

  { Parse StartupMode string. Can be one of 'normal', 'shell', or 'none'. Defaults to 'normal' }
  if CompareText(ExpandConstant('{param:startupmode}'), 'shell') = 0 then
    StartupModePage.SelectedValueIndex := 1
  else if CompareText(ExpandConstant('{param:startupmode}'), 'none') = 0 then
    StartupModePage.SelectedValueIndex := 2
  else
    StartupModePage.SelectedValueIndex := 0;

end;

function NextButtonClick(CurPageID: Integer): Boolean;
var
  i: Integer;
  Line, InvalidList: String;
begin
  Result := True;

  if CurPageID = PrintersPage.ID then
  begin
    InvalidList := '';

    for i := 0 to PrintersMemo.Lines.Count - 1 do
    begin
      Line := Trim(PrintersMemo.Lines[i]);
      if (Line <> '') and (not IsYamlSafeKey(Line)) then
      begin
        if InvalidList <> '' then InvalidList := InvalidList + ', ';
        InvalidList := InvalidList + Line;
      end;
    end;

    if InvalidList <> '' then
    begin
      MsgBox(
        CustomMessage('InvalidPrinterNames') + #13#10 + InvalidList + #13#10#13#10 + CustomMessage('InvalidPrinterNamesHint'),
        mbError, MB_OK
      );
      Result := False;
    end;
  end;
end;


function GetScheme(Param: String): String;
begin
  Result := ServerPage.Values[0];
end;

function GetHost(Param: String): String;
begin
  Result := ServerPage.Values[1];
end;

function GetPort(Param: String): String;
begin
  Result := ServerPage.Values[2];
end;

function GetLocation(Param: String): String;
begin
  Result := ClientPage.Values[0];
end;

function GetOnlyRunFor(Param: String): String;
begin
  Result := ClientPage.Values[1];
end;

function GetOnlyStopFor(Param: String): String;
begin
  Result := ClientPage.Values[2];
end;

function GetNodeName(Param: String): String;
begin
  Result := ClientPage.Values[3];
end;

function GetLogoutAction(Param: String): String;
begin
  case RebootActionPage.SelectedValueIndex of
    0: Result := 'reboot';
    1: Result := 'logout';
    2: Result := 'no_action';
  end;
end;

function GetPassword(Param: String): String;
begin
  Result := GetMD5OfString( PasswordPage.Values[0] );
end;

function CheckStartAfterShell(): Boolean;
begin
  Result := (StartupModePage.SelectedValueIndex = 0);
end;

function CheckShellReplacement(): Boolean;
begin
  Result := (StartupModePage.SelectedValueIndex = 1);
end;

procedure GetPrinterList(var Printers: TArrayOfString);
var
  i, Count: Integer;
  Line: String;
begin
  Count := 0;
  SetArrayLength(Printers, 0);

  for i := 0 to PrintersMemo.Lines.Count - 1 do
  begin
    Line := Trim(PrintersMemo.Lines[i]);
    if Line <> '' then
    begin
      SetArrayLength(Printers, Count + 1);
      Printers[Count] := Line;
      Inc(Count);
    end;
  end;
end;

{ Post-install logic: create folders, update INI, install clawPDF, import config }
procedure CurStepChanged(CurStep: TSetupStep);
var
  i: Integer;
  PrinterName: String;
  IniPath, ClawPDFIni, ClawPDFExe, SetupHelperExe: String;
  HasPrinters: Boolean;
  ResultCode: Integer;
  Printers: TArrayOfString;
begin
  if CurStep = ssPostInstall then
  begin
    HasPrinters := False;

    for i := 0 to PrintersMemo.Lines.Count - 1 do
    begin
      if Trim(PrintersMemo.Lines[i]) <> '' then
      begin
        HasPrinters := True;
        Break;
      end;
    end;
    if not HasPrinters then Exit;

    IniPath := ExpandConstant('{commonappdata}\Libki\Libki Kiosk Management System.ini');

    ForceDirectories('C:\printers');

    { Create each printer folder and INI entry }
    for i := 0 to PrintersMemo.Lines.Count - 1 do
    begin
      PrinterName := Trim(PrintersMemo.Lines[i]);
      if PrinterName <> '' then
      begin
        ForceDirectories('C:\printers\' + PrinterName);
        SetIniString('printers', PrinterName, 'C:\printers\' + PrinterName, IniPath);
      end;
    end;

    { Configure ClawPDF }
    ClawPDFExe := ExpandConstant('{autopf}\clawpdf\clawPDF.exe');
    SetupHelperExe := ExpandConstant('{autopf}\clawpdf\SetupHelper.exe');
    ClawPDFIni := ExpandConstant('{app}\windows\clawPDF4Libki.ini');
 
   if FileExists(ClawPDFExe) and FileExists(SetupHelperExe) then
    begin
      GetPrinterList(Printers);

      { Update ClawPDFIni with printer info }
      for i := 0 to PrintersMemo.Lines.Count - 1 do
      begin
        PrinterName := Trim(PrintersMemo.Lines[i]);
        if PrinterName <> '' then
        begin
          SetIniString('ApplicationSettings\PrinterMappings\' + IntToStr(i), 'PrinterName', PrinterName, ClawPDFIni);
          SetIniString('ApplicationSettings\PrinterMappings\' + IntToStr(i), 'ProfileGuid', '{#ProfileGuid}', ClawPDFIni);
          Exec(SetupHelperExe, '/Printer=Add /Name=' + PrinterName, '', SW_HIDE, ewWaitUntilTerminated, ResultCode);
        end;
      end;
      SetIniString('ApplicationSettings\PrinterMappings', 'numClasses', IntToStr(PrintersMemo.Lines.Count), ClawPDFIni);
      SetIniString('ApplicationSettings', 'PrimaryPrinter', Trim(PrintersMemo.Lines[0]), ClawPDFIni);
      SetIniString('ApplicationSettings', 'LastUsedProfileGuid', '{#ProfileGuid}', ClawPDFIni);
      
      { apply configs }
      if Exec(ClawPDFExe, '/Config="' + ClawPDFIni + '"', '', SW_HIDE, ewWaitUntilTerminated, ResultCode) then
      begin
        { configs ok }
      end
      else
      begin
        MsgBox(CustomMessage('ClawPDFImportFailed'), mbError, MB_OK);
      end
    end
    else
    begin
      MsgBox(
        CustomMessage('ClawPDFNotFound') + ' ' + ClawPDFExe,
        mbError,
        MB_OK
      );
    end;
  end;
end;

