TEMPLATE = app
TARGET = libkiclient
DEPENDPATH += .
INCLUDEPATH += .

QT += core
QT += gui
QT += network
QT += widgets

CONFIG += c++17

#CONFIG += console

# Input
HEADERS += loginwindow.h networkclient.h timerwindow.h \
    sessionlockedwindow.h \
    logutils.h \
    timesplash.h \
    utils.h \
    printprotocol.h \
    printsubmissionserver.h
FORMS += loginwindow.ui timerwindow.ui \
    sessionlockedwindow.ui
RESOURCES += libki.qrc
RC_FILE += libki.rc
SOURCES += loginwindow.cpp \
           main.cpp \
           networkclient.cpp \
           timerwindow.cpp \
           utils.cpp \
           sessionlockedwindow.cpp \
           logutils.cpp \
           timesplash.cpp \
           printsubmissionserver.cpp
TRANSLATIONS = languages/libkiclient_fr.ts \
        languages/libkiclient_sv.ts \
        languages/libkiclient_es.ts \
        languages/libkiclient_nb.ts \
        languages/libkiclient_pt.ts \
        languages/libkiclient_hu.ts \
        languages/libkiclient_de.ts \
        languages/libkiclient_cs.ts
OTHER_FILES +=

DISTFILES += \
    images/icons/libki.ico
