<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>LoginWindow</name>
    <message>
        <location filename="../loginwindow.ui" line="14"/>
        <source>Libki Kiosk System</source>
        <translation>Libki Kiosk-System</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="30"/>
        <source>Internet Kiosk</source>
        <translation>Internet-Kiosk</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="130"/>
        <location filename="../loginwindow.cpp" line="496"/>
        <source>Reserved</source>
        <translation>Reserviert</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="160"/>
        <source>Please Log In.</source>
        <translation>Bitte anmelden.</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="234"/>
        <source>Username:</source>
        <translation>Benutzername:</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="250"/>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="270"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="286"/>
        <source>Log In</source>
        <translation>Anmelden</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="306"/>
        <source>Guest Log In</source>
        <translation>Gastanmeldung</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="537"/>
        <source>2.3.0</source>
        <translation>2.3.0</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="585"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Unable to connect to server&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Keine Verbindung zum Server möglich&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../loginwindow.ui" line="609"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Unable to connect to Internet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Keine Verbindung zum Internet möglich&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="157"/>
        <location filename="../loginwindow.cpp" line="208"/>
        <source>Please Wait...</source>
        <translation>Bitte warten …</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="166"/>
        <location filename="../loginwindow.cpp" line="245"/>
        <source>Do you accept the terms of service?</source>
        <translation>Akzeptieren Sie die Nutzungsbedingungen?</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="171"/>
        <location filename="../loginwindow.cpp" line="250"/>
        <source>Terms of Service</source>
        <translation>Nutzungsbedingungen</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="185"/>
        <location filename="../loginwindow.cpp" line="264"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="186"/>
        <location filename="../loginwindow.cpp" line="265"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="286"/>
        <source>Login Failed: Username and password do not match</source>
        <translation>Anmeldung fehlgeschlagen: Benutzername und Passwort stimmen nicht überein</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="289"/>
        <source>Login Failed: You are not the correct age to use this client</source>
        <translation>Anmeldung fehlgeschlagen: Sie erfüllen nicht die Altersanforderung für diesen Kiosk</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="291"/>
        <source>Login Failed: No time left</source>
        <translation>Anmeldung fehlgeschlagen: Keine Zeit mehr verfügbar</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="293"/>
        <source>Login Failed: This kiosk is closed for the day</source>
        <translation>Anmeldung fehlgeschlagen: Dieser Kiosk ist für heute geschlossen</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="295"/>
        <source>Login Failed: Account is currently in use</source>
        <translation>Anmeldung fehlgeschlagen: Konto wird derzeit bereits verwendet</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="297"/>
        <source>Login Failed: Account is disabled</source>
        <translation>Anmeldung fehlgeschlagen: Konto ist gesperrt</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="300"/>
        <source>Login Failed: This kiosk is reserved for someone else</source>
        <translation>Anmeldung fehlgeschlagen: Dieser Kiosk ist für eine andere Person reserviert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="302"/>
        <source>Login Failed: Reservation required</source>
        <translation>Anmeldung fehlgeschlagen: Reservierung erforderlich</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="305"/>
        <location filename="../loginwindow.cpp" line="334"/>
        <source>Login Failed: You have excessive outstanding fees</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu hohe ausstehende Gebühren</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="307"/>
        <source>Login Failed: Charge privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Ausleihberechtigung verweigert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="309"/>
        <source>Login Failed: Renewal privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Verlängerungsberechtigung verweigert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="311"/>
        <source>Login Failed: Recall privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Vormerkberechtigung verweigert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="313"/>
        <source>Login Failed: Hold privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Vorbestellberechtigung verweigert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="315"/>
        <source>Login Failed: Your card has been reported lost</source>
        <translation>Anmeldung fehlgeschlagen: Ihr Ausweis wurde als verloren gemeldet</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="318"/>
        <source>Login Failed: You have too many items charged to your account</source>
        <translation>Anmeldung fehlgeschlagen: Zu viele Medien auf Ihr Konto ausgeliehen</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="320"/>
        <source>Login Failed: You have too many items overdue</source>
        <translation>Anmeldung fehlgeschlagen: Zu viele überfällige Medien</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="323"/>
        <source>Login Failed: You have renewed items too many times</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben Medien zu oft verlängert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="326"/>
        <source>Login Failed: You have claimed too many items as returned</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu viele Medien fälschlich als zurückgegeben gemeldet</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="328"/>
        <source>Login Failed: You have have lost too many items</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu viele Medien verloren</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="331"/>
        <source>Login Failed: You have excessive outstanding fines</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu hohe ausstehende Mahngebühren</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="337"/>
        <source>Login Failed: You have a recalled item which is overdue</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben ein vorgemerktes Medium, das überfällig ist</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="340"/>
        <source>Login Failed: You have been billed for too many items</source>
        <translation>Anmeldung fehlgeschlagen: Ihnen wurden zu viele Medien in Rechnung gestellt</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="342"/>
        <source>Login Failed: Client not registered</source>
        <translation>Anmeldung fehlgeschlagen: Client nicht registriert</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="344"/>
        <source>Login Failed: Unable to connect to ILS</source>
        <translation>Anmeldung fehlgeschlagen: Verbindung zum Bibliothekssystem (ILS) nicht möglich</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="347"/>
        <source>Login Failed: Too many concurrent sessions on this account</source>
        <translation>Anmeldung fehlgeschlagen: Zu viele gleichzeitige Sitzungen auf diesem Konto</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="350"/>
        <source>Login Failed: Expired Membership. Please inquire at the circulation desk.</source>
        <translation>Anmeldung fehlgeschlagen: Mitgliedschaft abgelaufen. Bitte wenden Sie sich an die Ausleihtheke.</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="353"/>
        <source>Login Failed: </source>
        <translation>Anmeldung fehlgeschlagen: </translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="494"/>
        <source>Reserved: </source>
        <translation>Reserviert: </translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="621"/>
        <source>This kiosk is out of order.</source>
        <translation>Dieser Kiosk ist außer Betrieb.</translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="639"/>
        <source>Error connecting to server. Verify Libki server is accessible from this network. Error Code: </source>
        <translation>Fehler bei der Verbindung zum Server. Bitte prüfen Sie, ob der Libki-Server aus diesem Netzwerk erreichbar ist. Fehlercode: </translation>
    </message>
    <message>
        <location filename="../loginwindow.cpp" line="652"/>
        <source>Error connecting to Internet: </source>
        <translation>Fehler bei der Internetverbindung: </translation>
    </message>
</context>
<context>
    <name>NetworkClient</name>
    <message>
        <location filename="../networkclient.cpp" line="1113"/>
        <source>Invalid JSON returned by server.</source>
        <translation>Ungültiges JSON vom Server zurückgegeben.</translation>
    </message>
</context>
<context>
    <name>PrintSubmissionServer</name>
    <message>
        <location filename="../printsubmissionserver.cpp" line="110"/>
        <source>Protocol version mismatch.</source>
        <translation>Protokollversion stimmt nicht überein.</translation>
    </message>
</context>
<context>
    <name>SessionLockedWindow</name>
    <message>
        <location filename="../sessionlockedwindow.ui" line="14"/>
        <source>Libki Kiosk System</source>
        <translation>Libki Kiosk-System</translation>
    </message>
    <message>
        <location filename="../sessionlockedwindow.ui" line="56"/>
        <source>Internet Kiosk</source>
        <translation>Internet-Kiosk</translation>
    </message>
    <message>
        <location filename="../sessionlockedwindow.ui" line="156"/>
        <source>Session Locked</source>
        <translation>Sitzung gesperrt</translation>
    </message>
    <message>
        <location filename="../sessionlockedwindow.ui" line="186"/>
        <source>Enter Password To Resume Session</source>
        <translation>Passwort eingeben, um die Sitzung fortzusetzen</translation>
    </message>
    <message>
        <location filename="../sessionlockedwindow.ui" line="260"/>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
    <message>
        <location filename="../sessionlockedwindow.ui" line="285"/>
        <source>Resume</source>
        <translation>Fortsetzen</translation>
    </message>
    <message>
        <location filename="../sessionlockedwindow.cpp" line="119"/>
        <source>Incorrect Password</source>
        <translation>Falsches Passwort</translation>
    </message>
</context>
<context>
    <name>TimerWindow</name>
    <message>
        <location filename="../timerwindow.ui" line="14"/>
        <source>Libki Kiosk System</source>
        <translation>Libki Kiosk-System</translation>
    </message>
    <message>
        <location filename="../timerwindow.ui" line="107"/>
        <location filename="../timerwindow.cpp" line="297"/>
        <source>Log Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <location filename="../timerwindow.ui" line="146"/>
        <source>Lock Session</source>
        <translation>Sitzung sperren</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="118"/>
        <source>You have one or more items on hold waiting for pickup. Please contact a librarian for more details</source>
        <translation>Sie haben ein oder mehrere vorgemerkte Medien zur Abholung bereit. Bitte wenden Sie sich für weitere Informationen an das Bibliothekspersonal</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="176"/>
        <location filename="../timerwindow.cpp" line="379"/>
        <source>Minutes Left</source>
        <translation>Minuten übrig</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="254"/>
        <source>Log Out?</source>
        <translation>Abmelden?</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="255"/>
        <source>Are you sure you want to log out?</source>
        <translation>Möchten Sie sich wirklich abmelden?</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="258"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="259"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="377"/>
        <source>Time Remaining</source>
        <translation>Verbleibende Zeit</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="456"/>
        <source>Inactivity detected</source>
        <translation>Inaktivität erkannt</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="457"/>
        <source>Please confirm you are still using this computer.</source>
        <translation>Bitte bestätigen Sie, dass Sie diesen Computer noch nutzen.</translation>
    </message>
    <message>
        <location filename="../timerwindow.cpp" line="492"/>
        <source>You have a message</source>
        <translation>Sie haben eine Nachricht</translation>
    </message>
</context>
</TS>
