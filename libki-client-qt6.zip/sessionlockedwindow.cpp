#include "sessionlockedwindow.h"

#include <QCryptographicHash>
#include <QMessageBox>
#include <QImage>
#include <QPixmap>

#include "utils.h"

SessionLockedWindow::SessionLockedWindow(QWidget *parent, QString userUsername,
                                         QString userPassword)
    : QMainWindow(parent) {
  qDebug("ENTER SessionLockedWindow::SessionLockedWindow");

  username = userUsername;
  password = userPassword;

  setAllowClose(false);

  setupUi(this);

  libkiIcon = QIcon(":images/libki_clock.png");
  this->setWindowIcon(libkiIcon);

  // Remove the maximize window button
  setWindowFlags((windowFlags() | Qt::CustomizeWindowHint) &
                 ~Qt::WindowMaximizeButtonHint);

  // Remove the close window button
  setWindowFlags((windowFlags() | Qt::CustomizeWindowHint) &
                 ~Qt::WindowSystemMenuHint);
  setWindowFlags((windowFlags() | Qt::CustomizeWindowHint) &
                 Qt::WindowStaysOnTopHint);
  setWindowFlags((windowFlags() | Qt::CustomizeWindowHint) &
                 Qt::X11BypassWindowManagerHint);
  setWindowFlags((windowFlags() | Qt::CustomizeWindowHint) &
                 Qt::FramelessWindowHint);

  setupActions();

  getSettings();

  clientNameLabel->setText(getClientName());

  // handleBanners(); // Do we really want banners on the lock screen?

  this->show();
  this->showMaximized();
  this->showFullScreen();

  this->raise();  // for MacOS
  this->activateWindow(); // for Windows

  qDebug("LEAVE SessionLockedWindow::SessionLockedWindow");
}

SessionLockedWindow::~SessionLockedWindow() {}

void SessionLockedWindow::setAllowClose(bool close) {
  qDebug("ENTER SessionLockedWindow::setAllowClose");

  allowClose = close;

  qDebug("LEAVE SessionLockedWindow::setAllowClose");
}

/* Reimplemented closeEvent to prevent application from being closed. */
void SessionLockedWindow::closeEvent(QCloseEvent *event) {
  qDebug("ENTER SessionLockedWindow::closeEvent");

  if (allowClose) {
    event->accept();
  } else {
    event->ignore();
  }

  qDebug("LEAVE SessionLockedWindow::closeEvent");
}

void SessionLockedWindow::getSettings() {
  qDebug("ENTER SessionLockedWindow::getSettings");

  /* Set Labels */
  QSettings settings;

  QString label = getLabel("password");
  if (!label.isEmpty()) {
    passwordLabel->setText(label);
  }

  if (!settings.value("images/logo").toString().isEmpty()) {
    logo->hide();

    QString logoUrl = settings.value("images/logo").toString();
    qDebug() << "Logo URL: " << logoUrl;

    if (!logoUrl.isEmpty()) {
      int logoWidth = settings.value("images/logo_width").toInt();
      int logoHeight = settings.value("images/logo_height").toInt();

      loadImageIntoLabel(logoWebView, QUrl(logoUrl), logoWidth, logoHeight);
    }
  } else {
    logoWebView->hide();
  }

  qDebug("LEAVE SessionLockedWindow::getSettings");
}

void SessionLockedWindow::attemptUnlock() {
  qDebug("ENTER SessionLockedWindow::attemptUnlock");

  QString passwordEntered = passwordField->text();

  if (passwordEntered == password) {
    passwordField->clear();
    emit unlockSession();
  } else {
    messageLabel->setText(tr("Incorrect Password"));
    passwordField->clear();
  }

  qDebug("LEAVE SessionLockedWindow::attemptUnlock");
}

void SessionLockedWindow::setupActions() {
  qDebug("ENTER SessionLockedWindow::setupActions");

  connect(resumeButton, SIGNAL(clicked()), this, SLOT(attemptUnlock()));

  //  connect(cancelButton, SIGNAL(clicked()),
  //          this, SLOT(resetSessionLockedScreen()));

  qDebug("LEAVE SessionLockedWindow::setupActions");
}

void SessionLockedWindow::loadImageIntoLabel(QLabel *label, const QUrl &url,
                                             int maxWidth, int maxHeight) {
  if (!url.isValid() || url.isEmpty()) {
    label->hide();
    return;
  }

  if (maxWidth > 0) label->setMaximumWidth(maxWidth);
  if (maxHeight > 0) label->setMaximumHeight(maxHeight);

  QNetworkAccessManager *nam = new QNetworkAccessManager(this);
  QObject::connect(
      nam, &QNetworkAccessManager::finished, this,
      [label, maxWidth, maxHeight](QNetworkReply *reply) {
        if (reply->error() == QNetworkReply::NoError) {
          QImage image;
          if (image.loadFromData(reply->readAll())) {
            QPixmap pixmap = QPixmap::fromImage(image);

            int w = maxWidth > 0 ? maxWidth : pixmap.width();
            int h = maxHeight > 0 ? maxHeight : pixmap.height();
            if (maxWidth > 0 || maxHeight > 0) {
              pixmap = pixmap.scaled(w, h, Qt::KeepAspectRatio,
                                     Qt::SmoothTransformation);
            }

            label->setPixmap(pixmap);
            label->setEnabled(true);
            label->show();
          } else {
            qWarning() << "Could not decode image data from"
                       << reply->url();
            label->hide();
          }
        } else {
          qWarning() << "Failed to download image from" << reply->url()
                     << ":" << reply->errorString();
          label->hide();
        }

        reply->deleteLater();
        reply->manager()->deleteLater();
      });

  nam->get(QNetworkRequest(url));
}
