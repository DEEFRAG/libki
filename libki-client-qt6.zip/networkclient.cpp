/*
 * Copyright 2010 Kyle M Hall <kyle.m.hall@gmail.com>
 *
 * This file is part of Libki.
 *
 * Libki is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Libki is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Libki.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "networkclient.h"
#include "utils.h"
#include "printsubmissionserver.h"
#include "printprotocol.h"

#include <QDir>
#include <QHttpMultiPart>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QList>
#include <QSslError>
#include <QUdpSocket>

#define VERSION "2.3.0"

// The Libki server (Perl/Catalyst) encodes "boolean" JSON fields using Perl
// truthiness idioms such as `$session && 1` or `!!$client`, which serialize
// as JSON numbers (1/0) or strings, not JSON `true`/`false` literals.
// QJsonValue::toBool() only returns true for an actual JSON boolean, so it
// silently treats these server responses as false. The Qt5 version of this
// client used QScriptValue::toBoolean(), which implements ECMAScript's
// ToBoolean semantics and therefore treated a numeric 1 as truthy. This
// helper restores that same "truthy" interpretation for QJsonValue.
static bool jsonTruthy(const QJsonValue &value) {
  switch (value.type()) {
    case QJsonValue::Null:
    case QJsonValue::Undefined:
      return false;
    case QJsonValue::Bool:
      return value.toBool();
    case QJsonValue::Double:
      return value.toDouble() != 0.0;
    case QJsonValue::String:
      return !value.toString().isEmpty();
    case QJsonValue::Array:
    case QJsonValue::Object:
      return true;
  }
  return false;
}

NetworkClient::NetworkClient(QApplication *app) : QObject() {
  qDebug("ENTER NetworkClient::NetworkClient");
  this->app = app;

  qDebug() << "SSL version use for build: "
           << QSslSocket::sslLibraryBuildVersionString();
  qDebug() << "SSL version use for run-time: "
           << QSslSocket::sslLibraryVersionNumber();

  fileCounter = 0;

  QSettings settings;

  nodeName = getClientName();

  nodeLocation = settings.value("node/location").toString();
  qDebug() << "LOCATION: " << nodeLocation;
  nodeType = settings.value("node/type").toString();
  qDebug() << "TYPE: " << nodeType;
  nodeAgeLimit = settings.value("node/age_limit").toString();
  qDebug() << "AGE LIMIT: " << nodeAgeLimit;

  QString action = settings.value("node/logoutAction").toString();

  if (action == "logout") {
    actionOnLogout = LogoutAction::Logout;
  } else if (action == "reboot") {
    actionOnLogout = LogoutAction::Reboot;
  } else {
    actionOnLogout = LogoutAction::NoAction;
  }

  clientStatus = "online";

  qDebug() << "HOST: " << settings.value("server/host").toString();
  serviceURL.setHost(settings.value("server/host").toString());
  serviceURL.setPort(settings.value("server/port").toInt());
  serviceURL.setScheme(settings.value("server/scheme").toString());
  serviceURL.setPath("/api/client/v1_0");

  customHeaderName = settings.value("server/customHeaderName").toString();
  customHeaderValue = settings.value("server/customHeaderValue").toString();

  nodeIPAddress = getIPv4Address();
  nodeMACAddress = getMACAddress();
  nodeHostname = getHostname();

  urlQuery.addQueryItem("node", nodeName);
  urlQuery.addQueryItem("location", nodeLocation);
  urlQuery.addQueryItem("type", nodeType);
  urlQuery.addQueryItem("ipaddress", nodeIPAddress);
  urlQuery.addQueryItem("macaddress", nodeMACAddress);
  urlQuery.addQueryItem("hostname", nodeHostname);

  registerNode();
  registerNodeTimer = new QTimer(this);
  connect(registerNodeTimer, SIGNAL(timeout()), this, SLOT(registerNode()));
  registerNodeTimer->start(1000 * 10);

  checkForInternetConnectivity();
  checkForInternetConnectivityTimer = new QTimer(this);
  connect(checkForInternetConnectivityTimer, SIGNAL(timeout()), this, SLOT(checkForInternetConnectivity()));
  checkForInternetConnectivityTimer->start(1000 * 10);

  uploadPrintJobsTimer = new QTimer(this);
  connect(uploadPrintJobsTimer, SIGNAL(timeout()), this,
          SLOT(uploadPrintJobs()));

  updateUserDataTimer = new QTimer(this);
  connect(updateUserDataTimer, SIGNAL(timeout()), this,
          SLOT(getUserDataUpdate()));

  printServer = new PrintSubmissionServer(this);

  if (printServer->start()) {
      qDebug() << "IPC server name:"
              << LIBKI_PRINT_SERVER_NAME;
  } else {
      qWarning() << "Print submission server could not be started.";
  }

  connect(printServer,
          SIGNAL(submitPrintRequested(SubmitPrintRequest)),
          this,
          SLOT(handlePrintRequest(SubmitPrintRequest)));

  connect(printServer,
          SIGNAL(printInfoRequested(PrintInfoRequest,QLocalSocket*)),
          this,
          SLOT(handlePrintInfoRequest(PrintInfoRequest,QLocalSocket*)));


  qDebug("LEAVE NetworkClient::NetworkClient");
}

void NetworkClient::attemptLogin(QString aUsername, QString aPassword, bool createGuest) {
  qDebug() << "ENTER NetworkClient::attemptLogin(" << aUsername << "," << aPassword << "," << createGuest << ")";

  username = aUsername;
  password = aPassword;

  QUrl url = QUrl(serviceURL);
  QUrlQuery query = QUrlQuery(urlQuery);
  query.addQueryItem("version", VERSION);
  query.addQueryItem("action", "login");
  query.addQueryItem("username", username);
  query.addQueryItem("password", password);
  query.addQueryItem("createGuest", createGuest ? "1" : "0");
  url.setQuery(query);

  qDebug() << "LOGIN URL: " << url.toString();
  qDebug() << "NetworkClient::attemptLogin";

  QNetworkAccessManager *nam;
  nam = new QNetworkAccessManager(this);
  QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
                   SLOT(processAttemptLoginReply(QNetworkReply *)));
  QObject::connect(
      nam, SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
      SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));

  /*QNetworkReply* reply = */ nam->get(buildRequest(url));
  qDebug("LEAVE NetworkClient::attemptLogin");
}

void NetworkClient::processAttemptLoginReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::processAttemptLogoutReply");

  handleNetworkReplyErrors(reply);

  QByteArray result;
  result = reply->readAll();

  QJsonDocument jsonResponse = QJsonDocument::fromJson(result);
  QJsonObject sc = jsonResponse.object();

  if (jsonTruthy(sc.value("authenticated")) == true) {
    qDebug("Login Authenticated");

    int units = sc.value("units").toInt();
    int hold_items_count = sc.value("hold_items_count").toInt();

    QString aUsername = sc.value("username").toString();
    QString aPassword = sc.value("password").toString();
    if ( aUsername.length() && aPassword.length() ) {
        username = aUsername;
        password = aPassword;
    }

    doLoginTasks(units, hold_items_count);
  } else {
    qDebug("Login Failed");

    QString errorCode = sc.value("error").toString();
    qDebug() << "Error Code: " << errorCode;

    username.clear();
    password.clear();

    emit loginFailed(errorCode);
  }

  reply->abort();
  reply->deleteLater();
  reply->manager()->deleteLater();

  qDebug("LEAVE NetworkClient::processAttemptLogoutReply");
}

void NetworkClient::attemptLogout() {
  qDebug("ENTER NetworkClient::attemptLogout");

  QNetworkAccessManager *nam;
  nam = new QNetworkAccessManager(this);
  QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
                   SLOT(processAttemptLogoutReply(QNetworkReply *)));
  QObject::connect(
      nam, SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
      SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));

  QUrl url = QUrl(serviceURL);
  QUrlQuery query = QUrlQuery(urlQuery);
  query.addQueryItem("version", VERSION);
  query.addQueryItem("action", "logout");
  query.addQueryItem("username", username);
  query.addQueryItem("password", password);
  url.setQuery(query);

  /*QNetworkReply* reply =*/nam->get(buildRequest(url));

  qDebug("LEAVE NetworkClient::attemptLogout");
}

void NetworkClient::processAttemptLogoutReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::processAttemptLogoutReply");

  handleNetworkReplyErrors(reply);

  QByteArray result;
  result = reply->readAll();

  QJsonDocument jsonResponse = QJsonDocument::fromJson(result);
  QJsonObject sc = jsonResponse.object();

  if (jsonTruthy(sc.value("logged_out")) == true) {
    doLogoutTasks();
  } else {
    emit logoutFailed();
  }

  reply->abort();
  reply->deleteLater();
  reply->manager()->deleteLater();

  qDebug("LEAVE NetworkClient::processAttemptLogoutReply");
}

void NetworkClient::getUserDataUpdate() {
  qDebug("ENTER NetworkClient::getUserDataUpdate");

  QNetworkAccessManager *nam = new QNetworkAccessManager(this);
  QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
                   SLOT(processGetUserDataUpdateReply(QNetworkReply *)));
  QObject::connect(
      nam, SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
      SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));

  QUrl url = QUrl(serviceURL);
  QUrlQuery query = QUrlQuery(urlQuery);
  query.addQueryItem("version", VERSION);
  query.addQueryItem("action", "get_user_data");
  query.addQueryItem("username", username);
  query.addQueryItem("password", password);
  url.setQuery(query);

  /*QNetworkReply* reply =*/nam->get(buildRequest(url));

  qDebug("LEAVE NetworkClient::getUserDataUpdate");
}

void NetworkClient::processGetUserDataUpdateReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::processGetUserDataUpdateReply");

  handleNetworkReplyErrors(reply);

  QByteArray result;
  result = reply->readAll();

  qDebug() << "Server Result: " << result;

  QJsonDocument jd = QJsonDocument::fromJson(result);

  if (jd.isObject()) {
    QJsonObject jo = jd.object();

    QString status = jo["status"].toString();
    qDebug() << "STATUS: " << status;

    if (status == "Logged in") {
      QJsonArray messages = jo["messages"].toArray();
      qDebug() << "MESSAGE ARRAY SIZE: " << messages.size();

      for (int i = 0; i < messages.size(); i++) {
        QString m = messages[i].toString();
        qDebug() << "MESSAGE: " << m;
        emit messageRecieved(m);
      }

      QJsonValueRef units_json = jo["units"];
      QVariant units_variant = units_json.toVariant();
      int units = units_variant.toInt();
      qDebug() << "UNITS JASON: " << units_json;
      qDebug() << "UNITS VARIANT: " << units_variant;
      qDebug() << "UNITS: " << units;

      emit timeUpdatedFromServer(units);

      if (units < 1) {
        doLogoutTasks();
      }
    } else if (status == "Logged out") {
      doLogoutTasks();
    } else if (status == "Kicked") {
      doLogoutTasks();
    }
  }

  reply->abort();
  reply->deleteLater();
  reply->manager()->deleteLater();

  qDebug("LEAVE NetworkClient::processGetUserDataUpdateReply");
}

void NetworkClient::uploadPrintJobs() {
  qDebug() << "NetworkClient::uploadPrintJobs";

  QSettings printerSettings;
  printerSettings.beginGroup("printers");
  QStringList printers = printerSettings.allKeys();
  qDebug() << "PRINTER: " << printers;

  for (const QString &printer : std::as_const(printers)) {
    qDebug() << "FOUND PRINTER: " << printer;
    qDebug() << "PATH: " << printerSettings.value(printer).toString();

    QString directory = printerSettings.value(printer).toString();
    QDir dir(directory);

    if (!dir.exists()) {
      qDebug() << "Directory does not exist: " << directory;
      bool s = dir.mkpath(directory);
      qDebug() << "Attempt to create directory result: " << s;
    }

    dir.setFilter(QDir::Files);
    dir.setSorting(QDir::Time | QDir::Reversed);

    QFileInfoList list = dir.entryInfoList();

    for (int i = 0; i < list.size(); ++i) {

      QFileInfo fileInfo = list.at(i);
      QString absoluteFilePath = fileInfo.absoluteFilePath();

      SubmitPrintRequest request;

      request.filename = absoluteFilePath;
      request.printer = printer;
      request.copies = 0;
      request.pageCount = 0;

      uploadPrintJob(request);
    }
  }
  qDebug() << "LEAVE NetworkClient::uploadPrintJobs";
}

void NetworkClient::uploadPrintJob(const SubmitPrintRequest &request) {
  QFile *file = new QFile(request.filename);
  bool opened = file->open(QIODevice::ReadOnly);
  if ( !opened ) {
    qDebug() << "OPENING FILE " << request.filename << " FAILED! SKIPPING FILE.";
    return;
  }
  QFileInfo fileInfo(request.filename);
  QString fileNameOnly = fileInfo.fileName();

  // If the file is less than 1 kb, it's still being written. An empty PDF is about 3.7K
  if ( fileInfo.size() < 2048 ) {
    qWarning() << "File size too small: " << fileNameOnly;
    return;
  }

  // If the file is not writable, the print driver hasn't finished writing the PDF
  if (!fileInfo.isWritable()) {
    qWarning() << "File not writable: " << fileNameOnly;
    return;
  }
  const QString printedFileSuffix = ".printed";

  if (request.filename.endsWith(printedFileSuffix)) {
    return;
  }
  qDebug() << "SENDING PRINT JOB: " << fileNameOnly;

  QString fileCounterString = QString::number(fileCounter);
  fileCounter++;

  QString newAbsoluteFilePath =
      request.filename + "." + fileCounterString + printedFileSuffix;
  bool renamed = file->rename(request.filename, newAbsoluteFilePath);
  if ( !renamed ) {
    qWarning() << "RENAME FROM " << request.filename << " TO " << printedFileSuffix << " FAILED! SKIPPING FILE.";
    return;
  }

  QHttpMultiPart *multiPart =
      new QHttpMultiPart(QHttpMultiPart::FormDataType);

          // We con't delete the file object now, delete it with the multiPart
  file->setParent(multiPart);

  QHttpPart clientNamePart;
  clientNamePart.setHeader(QNetworkRequest::ContentDispositionHeader,
                           QVariant("form-data; name=client_name"));
  QByteArray clientNameQBA;
  clientNameQBA.append(nodeName.toUtf8());
  clientNamePart.setBody(clientNameQBA);
  multiPart->append(clientNamePart);

  QHttpPart userNamePart;
  userNamePart.setHeader(QNetworkRequest::ContentDispositionHeader,
                         QVariant("form-data; name=username"));
  QByteArray userNameQBA;
  userNameQBA.append(username.toUtf8());
  userNamePart.setBody(userNameQBA);
  multiPart->append(userNamePart);

  QHttpPart printerNamePart;
  printerNamePart.setHeader(QNetworkRequest::ContentDispositionHeader,
                            QVariant("form-data; name=printer"));
  QByteArray printerNameQBA;
  printerNameQBA.append(request.printer.toUtf8());
  printerNamePart.setBody(printerNameQBA);
  multiPart->append(printerNamePart);

  QHttpPart printJobPart;
  printJobPart.setHeader(
      QNetworkRequest::ContentDispositionHeader,
      QVariant("form-data; name=print_file; filename=" + fileNameOnly));
  printJobPart.setBodyDevice(file);
  multiPart->append(printJobPart);

  QHttpPart fileNamePart;
  fileNamePart.setHeader(QNetworkRequest::ContentDispositionHeader,
                         QVariant("form-data; name=filename"));
  QByteArray fileNameQBA;
  fileNameQBA.append(fileNameOnly.toUtf8());
  fileNamePart.setBody(fileNameQBA);
  multiPart->append(fileNamePart);

  QHttpPart copiesPart;
  copiesPart.setHeader(
      QNetworkRequest::ContentDispositionHeader,
      QVariant("form-data; name=\"copies\""));
  copiesPart.setBody(
      QByteArray::number(request.copies));
  multiPart->append(copiesPart);

  QUrl printUrl = QUrl(serviceURL);
  printUrl.setPath("/api/client/v1_0/print");
  QNetworkRequest netrequest = buildRequest(printUrl);


  QNetworkAccessManager *networkManager = new QNetworkAccessManager(this);
  QObject::connect(
      networkManager,
      SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
      SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));

  QNetworkReply *reply = networkManager->post(netrequest, multiPart);
  multiPart->setParent(reply);  // delete the multiPart with the reply

          // TODO: delete file after finished signal emits
          // https://stackoverflow.com/questions/5153157/passing-an-argument-to-a-slot
  connect(networkManager, SIGNAL(finished(QNetworkReply *)), this,
          SLOT(uploadPrintJobReply(QNetworkReply *)));
  connect(reply, SIGNAL(uploadProgress(qint64, qint64)), this,
          SLOT(handleUploadProgress(qint64, qint64)));
}

void NetworkClient::handleUploadProgress(qint64 bytesSent, qint64 bytesTotal) {
  qDebug() << "Uploaded " << bytesSent << "of" << bytesTotal;
}

void NetworkClient::uploadPrintJobReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::uploadPrintJobReply");

  handleNetworkReplyErrors(reply);

  if (reply->error() == QNetworkReply::NoError) {
    reply->abort();
    reply->deleteLater();
    reply->manager()->deleteLater();
  } else {
    qWarning() << "Network Error: " << reply->errorString();
    qWarning() << "Retrying network request.";

    QNetworkRequest request = reply->request();

    QHttpMultiPart *multiPart = reply->findChild<QHttpMultiPart *>();
    qDebug() << "Found multiPart " << multiPart;

    QNetworkAccessManager *networkManager = new QNetworkAccessManager(this);
    QObject::connect(
        networkManager,
        SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
        SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));

    QNetworkReply *reply = networkManager->post(request, multiPart);

    multiPart->setParent(reply);  // delete the multiPart with the reply

    connect(networkManager, SIGNAL(finished(QNetworkReply *)), this,
            SLOT(uploadPrintJobReply(QNetworkReply *)));
    connect(reply, SIGNAL(uploadProgress(qint64, qint64)), this,
            SLOT(handleUploadProgress(qint64, qint64)));
  };

  qDebug("LEAVE NetworkClient::uploadPrintJobReply");
}

void NetworkClient::registerNode() {
  qDebug("ENTER NetworkClient::registerNode");

  QNetworkAccessManager *nam;
  nam = new QNetworkAccessManager(this);
  QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
                   SLOT(processRegisterNodeReply(QNetworkReply *)));

  QObject::connect(nam, SIGNAL(sslErrors(QNetworkReply *, QList<QSslError>)),
                   this,
                   SLOT(handleSslErrors(QNetworkReply *, QList<QSslError>)));

  QUrl url = QUrl(serviceURL);
  QUrlQuery query = QUrlQuery(urlQuery);
  query.addQueryItem("version", VERSION);
  query.addQueryItem("action", "register_node");
  query.addQueryItem("node_name", nodeName);
  query.addQueryItem("age_limit", nodeAgeLimit);
  url.setQuery(query);

  /*QNetworkReply* reply =*/nam->get(buildRequest(url));

  qDebug("LEAVE NetworkClient::registerNode");
}

void NetworkClient::handleSslErrors(QNetworkReply *reply,
                                    QList<QSslError> error) {
  reply->ignoreSslErrors(error);
}

void NetworkClient::processRegisterNodeReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::processRegisterNodeReply");

  handleNetworkReplyErrors(reply);

  QByteArray result;
  result = reply->readAll();

  qDebug() << "Server Result: " << result;

  QJsonDocument jsonResponse = QJsonDocument::fromJson(result);
  QJsonObject sc = jsonResponse.object();

  if (!jsonTruthy(sc.value("registered"))) {
    qWarning("Node Registration FAILED");
  }

  // TODO: Rename this to something like 'auto-login guest session'
  //  This feature is not related to session locking
  if (jsonTruthy(sc.value("unlock"))) {
    qDebug("Unlocking...");
    username = sc.value("username").toString();
    doLoginTasks(sc.value("minutes").toInt(), 0);
  }

  if (jsonTruthy(sc.value("shutdown"))) {
    qDebug("Received shutdown message from server");

    emit allowClose(true);

#ifdef Q_OS_WIN
    QProcess::startDetached("shutdown", QStringList() << "-s" << "-f" << "-t" << "0");
#endif  // ifdef Q_OS_WIN

#ifdef Q_OS_UNIX
    // For this to work, sudo must be installed and the line
    // %shutdown ALL=(root) NOPASSWD: /sbin/reboot FIXME
    // needs to be added to /etc/sudoers
    QProcess::startDetached("sudo", QStringList() << "shutdown" << "0");
#endif  // ifdef Q_OS_UNIX
  }

  if (jsonTruthy(sc.value("suspend"))) {
#ifdef Q_OS_WIN
    QProcess::startDetached("rundll32.exe", QStringList() << "powrprof.dll,SetSuspendState" << "0,1,0");
#endif  // ifdef Q_OS_WIN

#ifdef Q_OS_UNIX
    QProcess::startDetached("systemctl", QStringList() << "suspend" << "-i");
#endif  // ifdef Q_OS_UNIX
  }

  if (jsonTruthy(sc.value("restart"))) {
    emit allowClose(true);

#ifdef Q_OS_WIN
    QProcess::startDetached("shutdown", QStringList() << "-r" << "-f" << "-t" << "0");
#endif  // ifdef Q_OS_WIN

#ifdef Q_OS_UNIX
    // For this to work, sudo must be installed and the line
    // %shutdown ALL=(root) NOPASSWD: /sbin/reboot
    // needs to be added to /etc/sudoers
    QProcess::startDetached("sudo", QStringList() << "reboot");
#endif  // ifdef Q_OS_UNIX
  }

  if (jsonTruthy(sc.value("wakeup"))) {
    QStringList MAC_addresses;
    const QJsonArray macAddressesArray = sc.value("wol_mac_addresses").toArray();
    for (const QJsonValue &v : macAddressesArray) {
      MAC_addresses << v.toString();
    }
    wakeOnLan(MAC_addresses, sc.value("wol_host").toString(),
              sc.value("wol_port").toInt());
  }

  if (jsonTruthy(sc.value("drop"))) {
#ifdef Q_OS_WIN
    QProcess::startDetached("c:/windows/explorer.exe", QStringList());
    QProcess::startDetached("windows/on_login.exe", QStringList());
#endif  // ifdef Q_OS_WIN
    exit(1);
  }

  QString styleSheet = sc.value("ClientStyleSheet").toString();
  if (!styleSheet.isEmpty()) {
      this->app->setStyleSheet(styleSheet);
  }

  QSettings settings;

  QString bannerTopURL = settings.value("session/BannerTopURL").toString();
  QString bannerBottomURL =
      settings.value("session/BannerBottomURL").toString();

  settings.setValue("session/ClientBehavior",
                    sc.value("ClientBehavior").toString());
  settings.setValue("session/ReservationShowUsername",
                    sc.value("ReservationShowUsername").toString());
  settings.setValue("session/EnableClientSessionLocking",
                    sc.value("EnableClientSessionLocking").toString());
  settings.setValue("session/EnableClientPasswordlessMode",
                    sc.value("EnableClientPasswordlessMode").toString());
  settings.setValue("session/TermsOfService",
                    sc.value("TermsOfService").toString());
  settings.setValue("session/TermsOfServiceDetails",
                    sc.value("TermsOfServiceDetails").toString());

  settings.setValue("session/BannerTopURL",
                    sc.value("BannerTopURL").toString());
  settings.setValue("session/BannerTopWidth",
                    sc.value("BannerTopWidth").toString());
  settings.setValue("session/BannerTopHeight",
                    sc.value("BannerTopHeight").toString());

  settings.setValue("session/BannerBottomURL",
                    sc.value("BannerBottomURL").toString());
  settings.setValue("session/BannerBottomWidth",
                    sc.value("BannerBottomWidth").toString());
  settings.setValue("session/BannerBottomHeight",
                    sc.value("BannerBottomHeight").toString());

  settings.setValue("session/LogoURL",
                    sc.value("LogoURL").toString());
  settings.setValue("session/LogoWidth",
                    sc.value("LogoWidth").toString());
  settings.setValue("session/LogoHeight",
                    sc.value("LogoHeight").toString());

  settings.setValue("session/inactivityLogout",
                    sc.value("inactivityLogout").toString());
  settings.setValue("session/inactivityWarning",
                    sc.value("inactivityWarning").toString());

  settings.setValue("session/InternetConnectivityURLs",
                    sc.value("InternetConnectivityURLs").toString());

  settings.setValue("session/EnableGuestSelfRegistration",
                    sc.value("EnableGuestSelfRegistration").toString());

  settings.setValue("session/ShowTimeRemainingInSplash",
                    sc.value("ShowTimeRemainingInSplash").toString());
  settings.setValue("session/ShowTimeRemainingInTray",
                    sc.value("ShowTimeRemainingInTray").toString());

  settings.setValue("session/ClientTimeNotificationFrequency",
                    sc.value("ClientTimeNotificationFrequency").toString());
  settings.setValue("session/ClientTimeWarningThreshold",
                    sc.value("ClientTimeWarningThreshold").toString());
  settings.setValue("session/ClientTimeWarningFrequency",
                    sc.value("ClientTimeWarningFrequency").toString());

  QString logoURL = settings.value("images/logo").toString();
  if ( ! sc.value("Logo").toString().isEmpty() ) {
    settings.setValue("images/logo",
                      sc.value("Logo").toString());

    settings.setValue("images/logo_height",
                      sc.value("LogoHeight").toString());

    settings.setValue("images/logo_width",
                      sc.value("LogoWidth").toString());
  }

  QString guestRegistrationEnabled = settings.value("session/EnableGuestSelfRegistration").toString();

  settings.sync();

  if (
      (logoURL != sc.value("Logo").toString()) ||
      (bannerTopURL != sc.value("BannerTopURL").toString()) ||
      (bannerBottomURL != sc.value("BannerBottomURL").toString()) ||
      (guestRegistrationEnabled != sc.value("EnableGuestSelfRegistration").toString())
  ) {
    emit handleBanners();  // TODO: Emit only if a banner url has changed
  }

  QString reserved_for = sc.value("reserved_for").toString();
  emit setReservationStatus(reserved_for);

  QString status = sc.value("status").toString();
  if (status != clientStatus) {
    if (status == "suspended") {
      emit clientSuspended();
    } else if (status == "online") {
      emit clientOnline();
    }
  }
  clientStatus = status;

  reply->abort();
  reply->deleteLater();
  reply->manager()->deleteLater();

  qDebug("LEAVE NetworkClient::processRegisterNodeReply");
}

void NetworkClient::checkForInternetConnectivity() {
  qDebug("ENTER NetworkClient::checkForInternetConnectivity");

  QList<QString> list;

  QSettings settings;
  QString internetConnectivityURLs = settings.value("session/InternetConnectivityURLs").toString();
  //qDebug() << "URLS: " << internetConnectivityURLs;
  if ( internetConnectivityURLs != "null" ) {
      list = internetConnectivityURLs.split(QRegularExpression("[\r\n]"),Qt::SkipEmptyParts);
  }
  //qDebug() << "URLS LIST: " << list.join(" ");

  if ( list.size() ) {
      // Select a URL from the list at random to test connectivity
      QString url = list.at(QRandomGenerator::global()->bounded(list.size()));

      qDebug() << "CHECKING URL: " << url;

      QNetworkAccessManager *nam;
      nam = new QNetworkAccessManager(this);
      QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
               SLOT(processCheckForInternetConnectivityReply(QNetworkReply *)));
      QObject::connect(
          nam, SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
          SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));

      nam->get(QNetworkRequest(QUrl(url)));
  }

  qDebug("LEAVE NetworkClient::checkForInternetConnectivity");
}

void NetworkClient::processCheckForInternetConnectivityReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::processCheckForInternetConnectivityReply");

  if ( reply->error() != QNetworkReply::NoError ) {
      emit internetAccessWarning(reply->errorString());
      qWarning() << "NetworkClient::processCheckForInternetConnectivityReply Network Reply Error: " << reply->errorString();
  } else {
      emit internetAccessWarning("");
  }

  reply->abort();
  reply->deleteLater();
  reply->manager()->deleteLater();

  qDebug("LEAVE NetworkClient::processCheckForInternetConnectivityReply");
}

void NetworkClient::clearMessage() {
  qDebug("ENTER NetworkClient::clearMessage");

  QNetworkAccessManager *nam = new QNetworkAccessManager(this);
  QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
                   SLOT(ignoreNetworkReply(QNetworkReply *)));
  QObject::connect(
      nam, SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
      SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));
  QUrl url = QUrl(serviceURL);
  QUrlQuery query = QUrlQuery(urlQuery);
  query.addQueryItem("version", VERSION);
  query.addQueryItem("action", "clear_message");
  query.addQueryItem("username", username);
  query.addQueryItem("password", password);
  url.setQuery(query);
  nam->get(buildRequest(url));

  qDebug("LEAVE NetworkClient::clearMessage");
}

void NetworkClient::acknowledgeReservation(QString reserved_for) {
  qDebug("ENTER NetworkClient::acknowledgeReservation");

  QNetworkAccessManager *nam = new QNetworkAccessManager(this);
  QObject::connect(nam, SIGNAL(finished(QNetworkReply *)), this,
                   SLOT(ignoreNetworkReply(QNetworkReply *)));
  QObject::connect(
      nam, SIGNAL(sslErrors(QNetworkReply *, const QList<QSslError> &)), this,
      SLOT(handleSslErrors(QNetworkReply *, const QList<QSslError> &)));
  QUrl url = QUrl(serviceURL);
  QUrlQuery query = QUrlQuery(urlQuery);
  query.addQueryItem("version", VERSION);
  query.addQueryItem("action", "acknowledge_reservation");
  query.addQueryItem("reserved_for", reserved_for);
  url.setQuery(query);

  nam->get(buildRequest(url));

  qDebug("LEAVE NetworkClient::acknowledgeReservation");
}

void NetworkClient::ignoreNetworkReply(QNetworkReply *reply) {
  qDebug("ENTER NetworkClient::ignoreNetworkReply");

  handleNetworkReplyErrors(reply);

  reply->abort();
  reply->deleteLater();
  reply->manager()->deleteLater();

  qDebug("LEAVE NetworkClient::ignoreNetworkReply");
}

void NetworkClient::doLoginTasks(int units, int hold_items_count) {
  qDebug("ENTER NetworkClient::doLoginTasks");

#ifdef Q_OS_WIN
  // FIXME: We should delete print jobs at login as well in case a client crash
  // prevented the print jobs for getting cleaned up at logout time

  // If this is an MS Windows platform, use the keylocker programs to limit
  // mischief.
  QProcess::startDetached("c:/windows/explorer.exe", QStringList());
  QProcess::startDetached("windows/on_login.exe", QStringList());
#endif  // ifdef Q_OS_WIN

  uploadPrintJobsTimer->start(1000 * 2);
  updateUserDataTimer->start(1000 * 10);

  QSettings settings;
  settings.setValue("session/LoggedInUser", username);
  settings.sync();
  qDebug() << "SCRIPTLOGIN:" << settings.value("scriptlogin/enable").toString();
  if (settings.value("scriptlogin/enable").toString() == "1") {
    // scriptlogin/script may contain a program plus arguments; split it
    // the same way Qt5's single-argument startDetached() used to.
    QStringList scriptLoginParts =
        QProcess::splitCommand(settings.value("scriptlogin/script").toString());
    if (!scriptLoginParts.isEmpty()) {
      QString scriptLoginProgram = scriptLoginParts.takeFirst();
      QProcess::startDetached(scriptLoginProgram, scriptLoginParts);
    }
  }
  emit loginSucceeded(username, password, units, hold_items_count);

  qDebug("ENTER NetworkClient::doLoginTasks");
}

void NetworkClient::doLogoutTasks() {
  qDebug("ENTER NetworkClient::doLogoutTasks");

  QSettings settings;
  settings.setValue("session/LoggedInUser", "");
  settings.sync();

  // Delete print jobs
  QSettings printerSettings;
  printerSettings.beginGroup("printers");
  QStringList printers = printerSettings.allKeys();
  for (const QString &printer : std::as_const(printers)) {
    QString directory = printerSettings.value(printer).toString();
    QDir dir(directory);

    dir.setFilter(QDir::Files);

    QFileInfoList list = dir.entryInfoList();

    for (int i = 0; i < list.size(); ++i) {
      QFileInfo fileInfo = list.at(i);
      QString absoluteFilePath = fileInfo.absoluteFilePath();
      QFile::remove(absoluteFilePath);
    }
  }

  uploadPrintJobsTimer->stop();
  updateUserDataTimer->stop();

  username.clear();
  password.clear();

#ifdef Q_OS_WIN

  // If this is an MS Windows platform, use the keylocker programs to limit
  // mischief.
  QProcess::startDetached("taskkill", QStringList() << "/f" << "/im" << "explorer.exe");
  QProcess::startDetached("windows/on_logout.exe", QStringList());

  if (actionOnLogout == LogoutAction::Logout) {
    emit allowClose(true);
    QProcess::startDetached("shutdown", QStringList() << "-l" << "-f");
  } else if (actionOnLogout == LogoutAction::Reboot) {
    emit allowClose(true);
    QProcess::startDetached("shutdown", QStringList() << "-r" << "-f" << "-t" << "0");
  }
#endif  // ifdef Q_OS_WIN

#ifdef Q_OS_UNIX

  if (actionOnLogout == LogoutAction::Logout) {
    emit allowClose(true);

    // Restart KDE 4
    QProcess::startDetached(
        "qdbus",
        QStringList() << "org.kde.ksmserver" << "/KSMServer"
                      << "org.kde.KSMServerInterface.logout" << "-0" << "-1"
                      << "-1");

    // Restart Gnome
    QProcess::startDetached("gnome-session-save", QStringList() << "--kill" << "--silent");

    // Restart Unity
    QProcess::startDetached("gnome-session-quit", QStringList() << "--no-prompt");

    // Restart XFCE 4
    QProcess::startDetached("/usr/bin/xfce4-session-logout", QStringList());

    // Restart Mate
    QProcess::startDetached("mate-session-save", QStringList() << "--force-logout");
  } else if (actionOnLogout == LogoutAction::Reboot) {
    emit allowClose(true);

    // For this to work, sudo must be installed and the line
    // %shutdown ALL=(root) NOPASSWD: /sbin/reboot
    // needs to be added to /etc/sudoers
    QProcess::startDetached("sudo", QStringList() << "reboot");
  }
#endif  // ifdef Q_OS_UNIX
  qDebug() << "SCRIPTLOGOUT:"
           << settings.value("scriptlogout/enable").toString();
  if (settings.value("scriptlogout/enable").toString() == "1") {
    QStringList scriptLogoutParts = QProcess::splitCommand(
        settings.value("scriptlogout/script").toString());
    if (!scriptLogoutParts.isEmpty()) {
      QString scriptLogoutProgram = scriptLogoutParts.takeFirst();
      QProcess::startDetached(scriptLogoutProgram, scriptLogoutParts);
    }
  }
  emit logoutSucceeded();

  qDebug("LEAVE NetworkClient::doLogoutTasks");
}

void NetworkClient::wakeOnLan(QStringList MAC_addresses, QString host,
                              qint64 port) {
  qDebug("ENTER NetworkClient::wakeOnLan");

  QHostAddress host_address;
  host_address.setAddress(host);

  for (int i = 0; i < MAC_addresses.size(); i++) {
    char address[6];
    char packet[102];

    memset(packet, 0xff, 6);

    for (int j = 0; j < 6; j++) {
      address[j] = MAC_addresses.at(i).section(":", j, j).toInt(Q_NULLPTR, 16);
    }

    for (int j = 1; j <= 16; j++) {
      memcpy(&packet[j * 6], &address, 6 * sizeof(char));
    }

    QUdpSocket udpSocket;
    udpSocket.writeDatagram(packet, 102, host_address, port);
  }

  qDebug("LEAVE NetworkClient::wakeOnLan");
}

QNetworkRequest NetworkClient::buildRequest(const QUrl &url) const {
  QNetworkRequest request(url);
  if (!customHeaderName.isEmpty()) {
    request.setRawHeader(customHeaderName.toUtf8(), customHeaderValue.toUtf8());
  }
  return request;
}

void NetworkClient::handleNetworkReplyErrors(QNetworkReply *reply) {
  if ( reply->error() != QNetworkReply::NoError ) {
      QString e = QString::number(reply->error());
      qWarning() << "ERROR: Server Access Warning: " << e << " :: " << reply->errorString();

      QString s = e + ": " + reply->errorString();
      serverAccessWarning(s);
  } else {
      serverAccessWarning("");
  }
}

void NetworkClient::handlePrintRequest(const SubmitPrintRequest &request) {
  if (username.isEmpty()) {
    qWarning()
        << "Ignoring print request because no user is logged in.";
    return;
  }

  uploadPrintJob(request);
}

void NetworkClient::handlePrintInfoRequest(PrintInfoRequest request, QLocalSocket *socket) {
  qDebug("ENTER handlePrintInfoRequest");
  QNetworkAccessManager *nam = new QNetworkAccessManager(this);
  QUrl url(serviceURL);

  url.setPath("/api/client/v1_0/print_price_check");

  QUrlQuery query;

  query.addQueryItem("client_name", nodeName);
  query.addQueryItem("username", username);
  query.addQueryItem("printer", request.printer);

  url.setQuery(query);

  QNetworkReply *reply = nam->get(buildRequest(url));

  PendingPrintInfoRequest context;

  context.socket = socket;
  context.request = request;

  pendingPrintInfoReplies.insert(reply, context);

  connect(reply,
          SIGNAL(finished()),
          this,
          SLOT(processPrintPriceCheckReply()));
  qDebug("LEAVE handlePrintInfoRequest");
}

void NetworkClient::processPrintPriceCheckReply() {
  qDebug("ENTER processPrintPriceCheckReply");
  QNetworkReply *networkReply =
      qobject_cast<QNetworkReply *>(sender());

  if (!networkReply) {
    qWarning("No network reply");
    return;
  }
  PendingPrintInfoRequest context = pendingPrintInfoReplies.take(networkReply);

  PrintInfoReply reply;

  if (networkReply->error() != QNetworkReply::NoError) {
    reply.success = false;
    reply.error = networkReply->errorString();
    qWarning() << "Network reply error: " << reply.error;

    printServer->sendPrintInfoReply(
        context.socket,
        reply);

    networkReply->deleteLater();
    return;
  }

  QJsonParseError parseError;

  QJsonDocument doc = QJsonDocument::fromJson(networkReply->readAll(), &parseError);

  if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
    reply.success = false;
    reply.error = tr("Invalid JSON returned by server.");
    qWarning() << "JSON parsing error";

    printServer->sendPrintInfoReply(
        context.socket,
        reply);

    networkReply->deleteLater();
    return;
  }

  QJsonObject obj = doc.object();

  reply.success = true;
  reply.currency = obj.value("currency").toString();
  reply.costPerPage = obj.value("cpp").toDouble();
  reply.availableFunds = obj.value("funds").toDouble();
  reply.availableGratis = obj.value("gratis_balance").toDouble();
  reply.gratisMethod = obj.value("gratis_method").toString();

  int totalPages = context.request.pageCount * context.request.copies;
  reply.estimatedCost = reply.costPerPage * totalPages;

  if (reply.gratisMethod == "pages") {
    if (totalPages <= reply.availableGratis) {
      reply.estimatedCost = 0;
      reply.remainingGratisBalance = reply.availableGratis - totalPages;
    } else {
      reply.estimatedCost = reply.costPerPage * (totalPages - reply.availableGratis);
      reply.remainingGratisBalance = 0;
    }
  } else if (reply.gratisMethod == "funds") {
    if (reply.estimatedCost <= reply.availableGratis) {
      reply.remainingGratisBalance = reply.availableGratis - reply.estimatedCost;
      reply.estimatedCost = 0;
    } else {
      reply.estimatedCost = (reply.costPerPage * totalPages) - reply.availableGratis;
      reply.remainingGratisBalance = 0;
    }
  } else {
    qWarning() << "Invalid gratis method: " << reply.gratisMethod;
  }

  reply.remainingFundsBalance = reply.availableFunds - reply.estimatedCost;

  reply.canPrint = (reply.remainingFundsBalance >= 0.0);

  printServer->sendPrintInfoReply(
      context.socket,
      reply);

  networkReply->deleteLater();
  qDebug("LEAVE processPrintPriceCheckReply");
}
