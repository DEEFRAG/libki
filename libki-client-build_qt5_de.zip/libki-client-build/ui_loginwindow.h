/********************************************************************************
** Form generated from reading UI file 'loginwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINWINDOW_H
#define UI_LOGINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWebKitWidgets/QWebView>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QLabel *headerLabel;
    QHBoxLayout *logoWebViewLayout;
    QSpacerItem *horizontalSpacer_11;
    QWebView *logoWebView;
    QSpacerItem *horizontalSpacer_12;
    QLabel *logo;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *reservedLabel;
    QLabel *errorLabel;
    QLabel *messageLabel;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_5;
    QFormLayout *formLayout;
    QLabel *usernameLabel;
    QLineEdit *usernameField;
    QLabel *passwordLabel;
    QLineEdit *passwordField;
    QPushButton *cancelButton;
    QPushButton *loginButton;
    QPushButton *loginGuestButton;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer_7;
    QWebView *bannerWebViewBottom;
    QSpacerItem *horizontalSpacer_8;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_9;
    QWebView *bannerWebViewTop;
    QSpacerItem *horizontalSpacer_10;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer;
    QLabel *version;
    QLabel *watermark;
    QVBoxLayout *MessagesLayout;
    QLabel *serverAccessWarning;
    QLabel *internetAccessWarning;
    QLabel *clientNameLabel;
    QMenuBar *menubar;

    void setupUi(QMainWindow *LoginWindow)
    {
        if (LoginWindow->objectName().isEmpty())
            LoginWindow->setObjectName(QString::fromUtf8("LoginWindow"));
        LoginWindow->resize(1052, 1505);
        centralwidget = new QWidget(LoginWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        headerLabel = new QLabel(centralwidget);
        headerLabel->setObjectName(QString::fromUtf8("headerLabel"));
        QFont font;
        font.setPointSize(19);
        font.setBold(true);
        font.setWeight(75);
        headerLabel->setFont(font);
        headerLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(headerLabel);

        logoWebViewLayout = new QHBoxLayout();
        logoWebViewLayout->setObjectName(QString::fromUtf8("logoWebViewLayout"));
        logoWebViewLayout->setContentsMargins(-1, 0, -1, -1);
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        logoWebViewLayout->addItem(horizontalSpacer_11);

        logoWebView = new QWebView(centralwidget);
        logoWebView->setObjectName(QString::fromUtf8("logoWebView"));
        logoWebView->setUrl(QUrl(QString::fromUtf8("about:blank")));

        logoWebViewLayout->addWidget(logoWebView);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        logoWebViewLayout->addItem(horizontalSpacer_12);


        verticalLayout->addLayout(logoWebViewLayout);

        logo = new QLabel(centralwidget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/images/images/libki.png")));
        logo->setScaledContents(false);
        logo->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(logo);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        reservedLabel = new QLabel(centralwidget);
        reservedLabel->setObjectName(QString::fromUtf8("reservedLabel"));
        reservedLabel->setEnabled(true);
        QFont font1;
        font1.setFamily(QString::fromUtf8("Bitstream Charter"));
        font1.setPointSize(19);
        font1.setBold(true);
        font1.setWeight(75);
        reservedLabel->setFont(font1);
        reservedLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(reservedLabel);

        errorLabel = new QLabel(centralwidget);
        errorLabel->setObjectName(QString::fromUtf8("errorLabel"));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        errorLabel->setFont(font2);
        errorLabel->setFrameShape(QFrame::NoFrame);
        errorLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(errorLabel);

        messageLabel = new QLabel(centralwidget);
        messageLabel->setObjectName(QString::fromUtf8("messageLabel"));
        messageLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(messageLabel);


        horizontalLayout->addLayout(verticalLayout_2);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(10, 10, 10, 10);
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_5);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setLabelAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        formLayout->setContentsMargins(20, 20, 20, 20);
        usernameLabel = new QLabel(centralwidget);
        usernameLabel->setObjectName(QString::fromUtf8("usernameLabel"));
        usernameLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::LabelRole, usernameLabel);

        usernameField = new QLineEdit(centralwidget);
        usernameField->setObjectName(QString::fromUtf8("usernameField"));

        formLayout->setWidget(0, QFormLayout::FieldRole, usernameField);

        passwordLabel = new QLabel(centralwidget);
        passwordLabel->setObjectName(QString::fromUtf8("passwordLabel"));
        passwordLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(1, QFormLayout::LabelRole, passwordLabel);

        passwordField = new QLineEdit(centralwidget);
        passwordField->setObjectName(QString::fromUtf8("passwordField"));
        passwordField->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(1, QFormLayout::FieldRole, passwordField);

        cancelButton = new QPushButton(centralwidget);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/images/icons/ban-solid.svg"), QSize(), QIcon::Normal, QIcon::Off);
        cancelButton->setIcon(icon);

        formLayout->setWidget(2, QFormLayout::LabelRole, cancelButton);

        loginButton = new QPushButton(centralwidget);
        loginButton->setObjectName(QString::fromUtf8("loginButton"));
        QFont font3;
        font3.setPointSize(12);
        loginButton->setFont(font3);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/images/icons/sign-in-alt-solid.svg"), QSize(), QIcon::Normal, QIcon::Off);
        loginButton->setIcon(icon1);
        loginButton->setIconSize(QSize(36, 36));

        formLayout->setWidget(2, QFormLayout::FieldRole, loginButton);

        loginGuestButton = new QPushButton(centralwidget);
        loginGuestButton->setObjectName(QString::fromUtf8("loginGuestButton"));
        loginGuestButton->setEnabled(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/icons/images/icons/guest.png"), QSize(), QIcon::Normal, QIcon::Off);
        loginGuestButton->setIcon(icon2);
        loginGuestButton->setIconSize(QSize(32, 32));

        formLayout->setWidget(3, QFormLayout::FieldRole, loginGuestButton);


        horizontalLayout_4->addLayout(formLayout);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_6);


        verticalLayout->addLayout(horizontalLayout_4);


        gridLayout->addLayout(verticalLayout, 3, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 3, 2, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 5, 1, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_7);

        bannerWebViewBottom = new QWebView(centralwidget);
        bannerWebViewBottom->setObjectName(QString::fromUtf8("bannerWebViewBottom"));
        bannerWebViewBottom->setEnabled(false);
        bannerWebViewBottom->setMaximumSize(QSize(728, 90));
        bannerWebViewBottom->setMouseTracking(false);
        bannerWebViewBottom->setContextMenuPolicy(Qt::NoContextMenu);
        bannerWebViewBottom->setAcceptDrops(false);
        bannerWebViewBottom->setUrl(QUrl(QString::fromUtf8("about:blank")));

        horizontalLayout_7->addWidget(bannerWebViewBottom);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_8);


        gridLayout->addLayout(horizontalLayout_7, 6, 1, 1, 1);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_9);

        bannerWebViewTop = new QWebView(centralwidget);
        bannerWebViewTop->setObjectName(QString::fromUtf8("bannerWebViewTop"));
        bannerWebViewTop->setEnabled(false);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(bannerWebViewTop->sizePolicy().hasHeightForWidth());
        bannerWebViewTop->setSizePolicy(sizePolicy);
        bannerWebViewTop->setMinimumSize(QSize(0, 0));
        bannerWebViewTop->setMaximumSize(QSize(728, 90));
        bannerWebViewTop->setMouseTracking(false);
        bannerWebViewTop->setAcceptDrops(false);
        bannerWebViewTop->setUrl(QUrl(QString::fromUtf8("about:blank")));

        horizontalLayout_8->addWidget(bannerWebViewTop);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_10);


        gridLayout->addLayout(horizontalLayout_8, 1, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 2, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 3, 0, 1, 1);

        version = new QLabel(centralwidget);
        version->setObjectName(QString::fromUtf8("version"));
        version->setMinimumSize(QSize(110, 40));
        version->setMaximumSize(QSize(110, 40));
        version->setLayoutDirection(Qt::RightToLeft);
        version->setStyleSheet(QString::fromUtf8("padding-right: 25px"));
        version->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(version, 6, 2, 1, 1);

        watermark = new QLabel(centralwidget);
        watermark->setObjectName(QString::fromUtf8("watermark"));
        watermark->setMinimumSize(QSize(110, 40));
        watermark->setMaximumSize(QSize(110, 40));
        watermark->setPixmap(QPixmap(QString::fromUtf8(":/images/images/libki.png")));
        watermark->setScaledContents(true);

        gridLayout->addWidget(watermark, 6, 0, 1, 1);

        MessagesLayout = new QVBoxLayout();
        MessagesLayout->setObjectName(QString::fromUtf8("MessagesLayout"));
        serverAccessWarning = new QLabel(centralwidget);
        serverAccessWarning->setObjectName(QString::fromUtf8("serverAccessWarning"));
        QFont font4;
        font4.setPointSize(12);
        font4.setBold(true);
        font4.setWeight(75);
        serverAccessWarning->setFont(font4);
        serverAccessWarning->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
"color: red;"));
        serverAccessWarning->setTextFormat(Qt::RichText);
        serverAccessWarning->setAlignment(Qt::AlignCenter);

        MessagesLayout->addWidget(serverAccessWarning);

        internetAccessWarning = new QLabel(centralwidget);
        internetAccessWarning->setObjectName(QString::fromUtf8("internetAccessWarning"));
        internetAccessWarning->setFont(font4);
        internetAccessWarning->setStyleSheet(QString::fromUtf8("font-weight: bold;\n"
"color: red;"));
        internetAccessWarning->setAlignment(Qt::AlignCenter);

        MessagesLayout->addWidget(internetAccessWarning);


        gridLayout->addLayout(MessagesLayout, 4, 1, 1, 1);

        clientNameLabel = new QLabel(centralwidget);
        clientNameLabel->setObjectName(QString::fromUtf8("clientNameLabel"));
        clientNameLabel->setStyleSheet(QString::fromUtf8("padding-right: 25px"));
        clientNameLabel->setText(QString::fromUtf8(""));
        clientNameLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(clientNameLabel, 1, 2, 1, 1);

        LoginWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LoginWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1052, 21));
        LoginWindow->setMenuBar(menubar);
#if QT_CONFIG(shortcut)
        usernameLabel->setBuddy(usernameField);
        passwordLabel->setBuddy(passwordField);
#endif // QT_CONFIG(shortcut)
        QWidget::setTabOrder(usernameField, passwordField);
        QWidget::setTabOrder(passwordField, loginButton);
        QWidget::setTabOrder(loginButton, cancelButton);

        retranslateUi(LoginWindow);
        QObject::connect(passwordField, SIGNAL(returnPressed()), loginButton, SLOT(click()));
        QObject::connect(usernameField, SIGNAL(returnPressed()), passwordField, SLOT(setFocus()));

        QMetaObject::connectSlotsByName(LoginWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LoginWindow)
    {
        LoginWindow->setWindowTitle(QCoreApplication::translate("LoginWindow", "Libki Kiosk System", nullptr));
        headerLabel->setText(QCoreApplication::translate("LoginWindow", "Internet Kiosk", nullptr));
        logo->setText(QString());
        reservedLabel->setText(QCoreApplication::translate("LoginWindow", "Reserved", nullptr));
        errorLabel->setText(QString());
        messageLabel->setText(QCoreApplication::translate("LoginWindow", "Please Log In.", nullptr));
        usernameLabel->setText(QCoreApplication::translate("LoginWindow", "Username:", nullptr));
        passwordLabel->setText(QCoreApplication::translate("LoginWindow", "Password:", nullptr));
        cancelButton->setText(QCoreApplication::translate("LoginWindow", "Cancel", nullptr));
        loginButton->setText(QCoreApplication::translate("LoginWindow", "Log In", nullptr));
        loginGuestButton->setText(QCoreApplication::translate("LoginWindow", "Guest Log In", nullptr));
        version->setText(QCoreApplication::translate("LoginWindow", "2.3.0", nullptr));
        watermark->setText(QString());
        serverAccessWarning->setText(QCoreApplication::translate("LoginWindow", "<html><head/><body><p><span style=\" color:#ff0000;\">Unable to connect to server</span></p></body></html>", nullptr));
        internetAccessWarning->setText(QCoreApplication::translate("LoginWindow", "<html><head/><body><p><span style=\" color:#ff0000;\">Unable to connect to Internet</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginWindow: public Ui_LoginWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINWINDOW_H
