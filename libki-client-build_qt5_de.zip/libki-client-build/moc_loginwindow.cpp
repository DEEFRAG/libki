/****************************************************************************
** Meta object code from reading C++ file 'loginwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.13)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "loginwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'loginwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.13. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_LoginWindow_t {
    QByteArrayData data[25];
    char stringdata0[378];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_LoginWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_LoginWindow_t qt_meta_stringdata_LoginWindow = {
    {
QT_MOC_LITERAL(0, 0, 11), // "LoginWindow"
QT_MOC_LITERAL(1, 12, 14), // "loginSucceeded"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 8), // "username"
QT_MOC_LITERAL(4, 37, 8), // "password"
QT_MOC_LITERAL(5, 46, 7), // "minutes"
QT_MOC_LITERAL(6, 54, 16), // "hold_items_count"
QT_MOC_LITERAL(7, 71, 12), // "attemptLogin"
QT_MOC_LITERAL(8, 84, 11), // "createGuest"
QT_MOC_LITERAL(9, 96, 28), // "displayingReservationMessage"
QT_MOC_LITERAL(10, 125, 12), // "reserved_for"
QT_MOC_LITERAL(11, 138, 13), // "setAllowClose"
QT_MOC_LITERAL(12, 152, 18), // "displayLoginWindow"
QT_MOC_LITERAL(13, 171, 17), // "attemptGuestLogin"
QT_MOC_LITERAL(14, 189, 19), // "attemptLoginFailure"
QT_MOC_LITERAL(15, 209, 10), // "loginError"
QT_MOC_LITERAL(16, 220, 19), // "attemptLoginSuccess"
QT_MOC_LITERAL(17, 240, 23), // "handleReservationStatus"
QT_MOC_LITERAL(18, 264, 13), // "handleBanners"
QT_MOC_LITERAL(19, 278, 12), // "disableLogin"
QT_MOC_LITERAL(20, 291, 11), // "enableLogin"
QT_MOC_LITERAL(21, 303, 23), // "showServerAccessWarning"
QT_MOC_LITERAL(22, 327, 7), // "message"
QT_MOC_LITERAL(23, 335, 25), // "showInternetAccessWarning"
QT_MOC_LITERAL(24, 361, 16) // "resetLoginScreen"

    },
    "LoginWindow\0loginSucceeded\0\0username\0"
    "password\0minutes\0hold_items_count\0"
    "attemptLogin\0createGuest\0"
    "displayingReservationMessage\0reserved_for\0"
    "setAllowClose\0displayLoginWindow\0"
    "attemptGuestLogin\0attemptLoginFailure\0"
    "loginError\0attemptLoginSuccess\0"
    "handleReservationStatus\0handleBanners\0"
    "disableLogin\0enableLogin\0"
    "showServerAccessWarning\0message\0"
    "showInternetAccessWarning\0resetLoginScreen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_LoginWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    4,   94,    2, 0x06 /* Public */,
       7,    3,  103,    2, 0x06 /* Public */,
       9,    1,  110,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,  113,    2, 0x0a /* Public */,
      12,    0,  116,    2, 0x0a /* Public */,
       7,    0,  117,    2, 0x0a /* Public */,
      13,    0,  118,    2, 0x0a /* Public */,
      14,    1,  119,    2, 0x0a /* Public */,
      16,    4,  122,    2, 0x0a /* Public */,
      17,    1,  131,    2, 0x0a /* Public */,
      18,    0,  134,    2, 0x0a /* Public */,
      19,    0,  135,    2, 0x0a /* Public */,
      20,    0,  136,    2, 0x0a /* Public */,
      21,    1,  137,    2, 0x0a /* Public */,
      23,    1,  140,    2, 0x0a /* Public */,
      24,    0,  143,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Int, QMetaType::Int,    3,    4,    5,    6,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    3,    4,    8,
    QMetaType::Void, QMetaType::QString,   10,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Int, QMetaType::Int,    3,    4,    5,    6,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void,

       0        // eod
};

void LoginWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<LoginWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->loginSucceeded((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3])),(*reinterpret_cast< const int(*)>(_a[4]))); break;
        case 1: _t->attemptLogin((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const bool(*)>(_a[3]))); break;
        case 2: _t->displayingReservationMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->setAllowClose((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->displayLoginWindow(); break;
        case 5: _t->attemptLogin(); break;
        case 6: _t->attemptGuestLogin(); break;
        case 7: _t->attemptLoginFailure((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->attemptLoginSuccess((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 9: _t->handleReservationStatus((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 10: _t->handleBanners(); break;
        case 11: _t->disableLogin(); break;
        case 12: _t->enableLogin(); break;
        case 13: _t->showServerAccessWarning((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->showInternetAccessWarning((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 15: _t->resetLoginScreen(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (LoginWindow::*)(const QString & , const QString & , const int & , const int & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LoginWindow::loginSucceeded)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (LoginWindow::*)(const QString & , const QString & , const bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LoginWindow::attemptLogin)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (LoginWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&LoginWindow::displayingReservationMessage)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject LoginWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_LoginWindow.data,
    qt_meta_data_LoginWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *LoginWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *LoginWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_LoginWindow.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "Ui::LoginWindow"))
        return static_cast< Ui::LoginWindow*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int LoginWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void LoginWindow::loginSucceeded(const QString & _t1, const QString & _t2, const int & _t3, const int & _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void LoginWindow::attemptLogin(const QString & _t1, const QString & _t2, const bool _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void LoginWindow::displayingReservationMessage(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
