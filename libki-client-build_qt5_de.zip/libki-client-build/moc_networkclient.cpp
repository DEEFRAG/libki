/****************************************************************************
** Meta object code from reading C++ file 'networkclient.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.13)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "networkclient.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'networkclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.13. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_NetworkClient_t {
    QByteArrayData data[45];
    char stringdata0[743];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NetworkClient_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NetworkClient_t qt_meta_stringdata_NetworkClient = {
    {
QT_MOC_LITERAL(0, 0, 13), // "NetworkClient"
QT_MOC_LITERAL(1, 14, 14), // "loginSucceeded"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 8), // "username"
QT_MOC_LITERAL(4, 39, 8), // "password"
QT_MOC_LITERAL(5, 48, 7), // "minutes"
QT_MOC_LITERAL(6, 56, 16), // "hold_items_count"
QT_MOC_LITERAL(7, 73, 11), // "loginFailed"
QT_MOC_LITERAL(8, 85, 9), // "errorCode"
QT_MOC_LITERAL(9, 95, 21), // "timeUpdatedFromServer"
QT_MOC_LITERAL(10, 117, 15), // "logoutSucceeded"
QT_MOC_LITERAL(11, 133, 12), // "logoutFailed"
QT_MOC_LITERAL(12, 146, 15), // "messageRecieved"
QT_MOC_LITERAL(13, 162, 7), // "message"
QT_MOC_LITERAL(14, 170, 10), // "allowClose"
QT_MOC_LITERAL(15, 181, 20), // "setReservationStatus"
QT_MOC_LITERAL(16, 202, 12), // "reserved_for"
QT_MOC_LITERAL(17, 215, 13), // "handleBanners"
QT_MOC_LITERAL(18, 229, 15), // "clientSuspended"
QT_MOC_LITERAL(19, 245, 12), // "clientOnline"
QT_MOC_LITERAL(20, 258, 19), // "serverAccessWarning"
QT_MOC_LITERAL(21, 278, 21), // "internetAccessWarning"
QT_MOC_LITERAL(22, 300, 12), // "attemptLogin"
QT_MOC_LITERAL(23, 313, 11), // "createGuest"
QT_MOC_LITERAL(24, 325, 13), // "attemptLogout"
QT_MOC_LITERAL(25, 339, 22), // "acknowledgeReservation"
QT_MOC_LITERAL(26, 362, 12), // "registerNode"
QT_MOC_LITERAL(27, 375, 24), // "processRegisterNodeReply"
QT_MOC_LITERAL(28, 400, 14), // "QNetworkReply*"
QT_MOC_LITERAL(29, 415, 5), // "reply"
QT_MOC_LITERAL(30, 421, 15), // "uploadPrintJobs"
QT_MOC_LITERAL(31, 437, 17), // "getUserDataUpdate"
QT_MOC_LITERAL(32, 455, 29), // "processGetUserDataUpdateReply"
QT_MOC_LITERAL(33, 485, 12), // "clearMessage"
QT_MOC_LITERAL(34, 498, 18), // "ignoreNetworkReply"
QT_MOC_LITERAL(35, 517, 19), // "uploadPrintJobReply"
QT_MOC_LITERAL(36, 537, 20), // "handleUploadProgress"
QT_MOC_LITERAL(37, 558, 24), // "processAttemptLoginReply"
QT_MOC_LITERAL(38, 583, 25), // "processAttemptLogoutReply"
QT_MOC_LITERAL(39, 609, 15), // "handleSslErrors"
QT_MOC_LITERAL(40, 625, 16), // "QList<QSslError>"
QT_MOC_LITERAL(41, 642, 5), // "error"
QT_MOC_LITERAL(42, 648, 28), // "checkForInternetConnectivity"
QT_MOC_LITERAL(43, 677, 40), // "processCheckForInternetConnec..."
QT_MOC_LITERAL(44, 718, 24) // "handleNetworkReplyErrors"

    },
    "NetworkClient\0loginSucceeded\0\0username\0"
    "password\0minutes\0hold_items_count\0"
    "loginFailed\0errorCode\0timeUpdatedFromServer\0"
    "logoutSucceeded\0logoutFailed\0"
    "messageRecieved\0message\0allowClose\0"
    "setReservationStatus\0reserved_for\0"
    "handleBanners\0clientSuspended\0"
    "clientOnline\0serverAccessWarning\0"
    "internetAccessWarning\0attemptLogin\0"
    "createGuest\0attemptLogout\0"
    "acknowledgeReservation\0registerNode\0"
    "processRegisterNodeReply\0QNetworkReply*\0"
    "reply\0uploadPrintJobs\0getUserDataUpdate\0"
    "processGetUserDataUpdateReply\0"
    "clearMessage\0ignoreNetworkReply\0"
    "uploadPrintJobReply\0handleUploadProgress\0"
    "processAttemptLoginReply\0"
    "processAttemptLogoutReply\0handleSslErrors\0"
    "QList<QSslError>\0error\0"
    "checkForInternetConnectivity\0"
    "processCheckForInternetConnectivityReply\0"
    "handleNetworkReplyErrors"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NetworkClient[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      31,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    4,  169,    2, 0x06 /* Public */,
       7,    1,  178,    2, 0x06 /* Public */,
       9,    1,  181,    2, 0x06 /* Public */,
      10,    0,  184,    2, 0x06 /* Public */,
      11,    0,  185,    2, 0x06 /* Public */,
      12,    1,  186,    2, 0x06 /* Public */,
      14,    1,  189,    2, 0x06 /* Public */,
      15,    1,  192,    2, 0x06 /* Public */,
      17,    0,  195,    2, 0x06 /* Public */,
      18,    0,  196,    2, 0x06 /* Public */,
      19,    0,  197,    2, 0x06 /* Public */,
      20,    1,  198,    2, 0x06 /* Public */,
      21,    1,  201,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      22,    3,  204,    2, 0x0a /* Public */,
      24,    0,  211,    2, 0x0a /* Public */,
      25,    1,  212,    2, 0x0a /* Public */,
      26,    0,  215,    2, 0x08 /* Private */,
      27,    1,  216,    2, 0x08 /* Private */,
      30,    0,  219,    2, 0x08 /* Private */,
      31,    0,  220,    2, 0x08 /* Private */,
      32,    1,  221,    2, 0x08 /* Private */,
      33,    0,  224,    2, 0x08 /* Private */,
      34,    1,  225,    2, 0x08 /* Private */,
      35,    1,  228,    2, 0x08 /* Private */,
      36,    2,  231,    2, 0x08 /* Private */,
      37,    1,  236,    2, 0x08 /* Private */,
      38,    1,  239,    2, 0x08 /* Private */,
      39,    2,  242,    2, 0x08 /* Private */,
      42,    0,  247,    2, 0x08 /* Private */,
      43,    1,  248,    2, 0x08 /* Private */,
      44,    1,  251,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Int, QMetaType::Int,    3,    4,    5,    6,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   13,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    3,    4,   23,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void, QMetaType::LongLong, QMetaType::LongLong,    2,    2,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void, 0x80000000 | 28, 0x80000000 | 40,   29,   41,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void, 0x80000000 | 28,   29,

       0        // eod
};

void NetworkClient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<NetworkClient *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->loginSucceeded((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3])),(*reinterpret_cast< const int(*)>(_a[4]))); break;
        case 1: _t->loginFailed((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->timeUpdatedFromServer((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->logoutSucceeded(); break;
        case 4: _t->logoutFailed(); break;
        case 5: _t->messageRecieved((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->allowClose((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->setReservationStatus((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->handleBanners(); break;
        case 9: _t->clientSuspended(); break;
        case 10: _t->clientOnline(); break;
        case 11: _t->serverAccessWarning((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->internetAccessWarning((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->attemptLogin((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 14: _t->attemptLogout(); break;
        case 15: _t->acknowledgeReservation((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 16: _t->registerNode(); break;
        case 17: _t->processRegisterNodeReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 18: _t->uploadPrintJobs(); break;
        case 19: _t->getUserDataUpdate(); break;
        case 20: _t->processGetUserDataUpdateReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 21: _t->clearMessage(); break;
        case 22: _t->ignoreNetworkReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 23: _t->uploadPrintJobReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 24: _t->handleUploadProgress((*reinterpret_cast< qint64(*)>(_a[1])),(*reinterpret_cast< qint64(*)>(_a[2]))); break;
        case 25: _t->processAttemptLoginReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 26: _t->processAttemptLogoutReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 27: _t->handleSslErrors((*reinterpret_cast< QNetworkReply*(*)>(_a[1])),(*reinterpret_cast< QList<QSslError>(*)>(_a[2]))); break;
        case 28: _t->checkForInternetConnectivity(); break;
        case 29: _t->processCheckForInternetConnectivityReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 30: _t->handleNetworkReplyErrors((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 17:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 22:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 23:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 25:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 26:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 27:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QSslError> >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 29:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        case 30:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QNetworkReply* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (NetworkClient::*)(const QString & , const QString & , const int & , const int & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::loginSucceeded)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::loginFailed)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::timeUpdatedFromServer)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::logoutSucceeded)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::logoutFailed)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::messageRecieved)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::allowClose)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::setReservationStatus)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::handleBanners)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::clientSuspended)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::clientOnline)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::serverAccessWarning)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (NetworkClient::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&NetworkClient::internetAccessWarning)) {
                *result = 12;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject NetworkClient::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_NetworkClient.data,
    qt_meta_data_NetworkClient,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *NetworkClient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NetworkClient::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NetworkClient.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int NetworkClient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 31)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 31;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 31)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 31;
    }
    return _id;
}

// SIGNAL 0
void NetworkClient::loginSucceeded(const QString & _t1, const QString & _t2, const int & _t3, const int & _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t3))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t4))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void NetworkClient::loginFailed(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void NetworkClient::timeUpdatedFromServer(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void NetworkClient::logoutSucceeded()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void NetworkClient::logoutFailed()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void NetworkClient::messageRecieved(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void NetworkClient::allowClose(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void NetworkClient::setReservationStatus(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void NetworkClient::handleBanners()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void NetworkClient::clientSuspended()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void NetworkClient::clientOnline()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void NetworkClient::serverAccessWarning(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void NetworkClient::internetAccessWarning(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
