/****************************************************************************
** Meta object code from reading C++ file 'timerwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.13)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "timerwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'timerwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.13. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TimerWindow_t {
    QByteArrayData data[23];
    char stringdata0[342];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TimerWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TimerWindow_t qt_meta_stringdata_TimerWindow = {
    {
QT_MOC_LITERAL(0, 0, 11), // "TimerWindow"
QT_MOC_LITERAL(1, 12, 13), // "requestLogout"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 12), // "timerStopped"
QT_MOC_LITERAL(4, 40, 27), // "serverAccountMinutesRequest"
QT_MOC_LITERAL(5, 68, 13), // "setAllowClose"
QT_MOC_LITERAL(6, 82, 10), // "startTimer"
QT_MOC_LITERAL(7, 93, 8), // "username"
QT_MOC_LITERAL(8, 102, 8), // "password"
QT_MOC_LITERAL(9, 111, 7), // "minutes"
QT_MOC_LITERAL(10, 119, 16), // "hold_items_count"
QT_MOC_LITERAL(11, 136, 9), // "stopTimer"
QT_MOC_LITERAL(12, 146, 14), // "updateTimeLeft"
QT_MOC_LITERAL(13, 161, 11), // "showMessage"
QT_MOC_LITERAL(14, 173, 7), // "message"
QT_MOC_LITERAL(15, 181, 11), // "lockSession"
QT_MOC_LITERAL(16, 193, 13), // "unlockSession"
QT_MOC_LITERAL(17, 207, 14), // "doLogoutDialog"
QT_MOC_LITERAL(18, 222, 18), // "restoreTimerWindow"
QT_MOC_LITERAL(19, 241, 13), // "iconActivated"
QT_MOC_LITERAL(20, 255, 33), // "QSystemTrayIcon::ActivationRe..."
QT_MOC_LITERAL(21, 289, 33), // "showSystemTrayIconTimeLeftMes..."
QT_MOC_LITERAL(22, 323, 18) // "checkForInactivity"

    },
    "TimerWindow\0requestLogout\0\0timerStopped\0"
    "serverAccountMinutesRequest\0setAllowClose\0"
    "startTimer\0username\0password\0minutes\0"
    "hold_items_count\0stopTimer\0updateTimeLeft\0"
    "showMessage\0message\0lockSession\0"
    "unlockSession\0doLogoutDialog\0"
    "restoreTimerWindow\0iconActivated\0"
    "QSystemTrayIcon::ActivationReason\0"
    "showSystemTrayIconTimeLeftMessage\0"
    "checkForInactivity"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TimerWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   89,    2, 0x06 /* Public */,
       3,    0,   90,    2, 0x06 /* Public */,
       4,    0,   91,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   92,    2, 0x0a /* Public */,
       6,    4,   95,    2, 0x0a /* Public */,
      11,    0,  104,    2, 0x0a /* Public */,
      12,    1,  105,    2, 0x0a /* Public */,
      13,    1,  108,    2, 0x0a /* Public */,
      15,    0,  111,    2, 0x0a /* Public */,
      16,    0,  112,    2, 0x0a /* Public */,
      17,    0,  113,    2, 0x08 /* Private */,
      18,    0,  114,    2, 0x08 /* Private */,
      19,    1,  115,    2, 0x08 /* Private */,
      21,    0,  118,    2, 0x08 /* Private */,
      22,    0,  119,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Int, QMetaType::Int,    7,    8,    9,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,    2,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TimerWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<TimerWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->requestLogout(); break;
        case 1: _t->timerStopped(); break;
        case 2: _t->serverAccountMinutesRequest(); break;
        case 3: _t->setAllowClose((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->startTimer((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 5: _t->stopTimer(); break;
        case 6: _t->updateTimeLeft((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->showMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->lockSession(); break;
        case 9: _t->unlockSession(); break;
        case 10: _t->doLogoutDialog(); break;
        case 11: _t->restoreTimerWindow(); break;
        case 12: _t->iconActivated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 13: _t->showSystemTrayIconTimeLeftMessage(); break;
        case 14: _t->checkForInactivity(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (TimerWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TimerWindow::requestLogout)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (TimerWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TimerWindow::timerStopped)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (TimerWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TimerWindow::serverAccountMinutesRequest)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject TimerWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_TimerWindow.data,
    qt_meta_data_TimerWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *TimerWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TimerWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TimerWindow.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "Ui::TimerWindow"))
        return static_cast< Ui::TimerWindow*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int TimerWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void TimerWindow::requestLogout()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void TimerWindow::timerStopped()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void TimerWindow::serverAccountMinutesRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
