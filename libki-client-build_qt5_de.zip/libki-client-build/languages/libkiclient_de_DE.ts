<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>LoginWindow</name>
    <message>
        <source>Libki Kiosk System</source>
        <translation>Libki Kiosk-System</translation>
    </message>
    <message>
        <source>Internet Kiosk</source>
        <translation>Internet-Terminal</translation>
    </message>
    <message>
        <source>about:blank</source>
        <translation></translation>
    </message>
    <message>
        <source>Reserved</source>
        <translation>Reserviert</translation>
    </message>
    <message>
        <source>Please Log In.</source>
        <translation>Bitte anmelden.</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Benutzername:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Log In</source>
        <translation>Anmelden</translation>
    </message>
    <message>
        <source>Guest Log In</source>
        <translation>Gast-Anmeldung</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Unable to connect to server&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Verbindung zum Server nicht möglich&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Unable to connect to Internet&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ff0000;&quot;&gt;Verbindung zum Internet nicht möglich&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Please Wait...</source>
        <translation>Bitte warten...</translation>
    </message>
    <message>
        <source>Do you accept the terms of service?</source>
        <translation>Akzeptieren Sie die Nutzungsbedingungen?</translation>
    </message>
    <message>
        <source>Terms of Service</source>
        <translation>Nutzungsbedingungen</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <source>Login Failed: Username and password do not match</source>
        <translation>Anmeldung fehlgeschlagen: Benutzername und Passwort stimmen nicht überein</translation>
    </message>
    <message>
        <source>Login Failed: You are not the correct age to use this client</source>
        <translation>Anmeldung fehlgeschlagen: Sie erfüllen nicht die Altersvoraussetzung für dieses Gerät</translation>
    </message>
    <message>
        <source>Login Failed: No time left</source>
        <translation>Anmeldung fehlgeschlagen: Keine Zeit mehr verfügbar</translation>
    </message>
    <message>
        <source>Login Failed: This kiosk is closed for the day</source>
        <translation>Anmeldung fehlgeschlagen: Dieses Gerät ist für heute geschlossen</translation>
    </message>
    <message>
        <source>Login Failed: Account is currently in use</source>
        <translation>Anmeldung fehlgeschlagen: Konto wird bereits verwendet</translation>
    </message>
    <message>
        <source>Login Failed: Account is disabled</source>
        <translation>Anmeldung fehlgeschlagen: Konto ist deaktiviert</translation>
    </message>
    <message>
        <source>Login Failed: This kiosk is reserved for someone else</source>
        <translation>Anmeldung fehlgeschlagen: Dieses Gerät ist für eine andere Person reserviert</translation>
    </message>
    <message>
        <source>Login Failed: Reservation required</source>
        <translation>Anmeldung fehlgeschlagen: Reservierung erforderlich</translation>
    </message>
    <message>
        <source>Login Failed: You have excessive outstanding fees</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu hohe ausstehende Gebühren</translation>
    </message>
    <message>
        <source>Login Failed: Charge privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Ausleiherechte verweigert</translation>
    </message>
    <message>
        <source>Login Failed: Renewal privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Verlängerungsrechte verweigert</translation>
    </message>
    <message>
        <source>Login Failed: Recall privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Rückforderungsrechte verweigert</translation>
    </message>
    <message>
        <source>Login Failed: Hold privileges denied</source>
        <translation>Anmeldung fehlgeschlagen: Vormerkrechte verweigert</translation>
    </message>
    <message>
        <source>Login Failed: Your card has been reported lost</source>
        <translation>Anmeldung fehlgeschlagen: Ihr Ausweis wurde als verloren gemeldet</translation>
    </message>
    <message>
        <source>Login Failed: You have too many items charged to your account</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu viele Medien auf Ihrem Konto ausgeliehen</translation>
    </message>
    <message>
        <source>Login Failed: You have too many items overdue</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu viele überfällige Medien</translation>
    </message>
    <message>
        <source>Login Failed: You have renewed items too many times</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben Medien zu oft verlängert</translation>
    </message>
    <message>
        <source>Login Failed: You have claimed too many items as returned</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu viele Medien fälschlich als zurückgegeben gemeldet</translation>
    </message>
    <message>
        <source>Login Failed: You have have lost too many items</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu viele Medien verloren</translation>
    </message>
    <message>
        <source>Login Failed: You have excessive outstanding fines</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben zu hohe ausstehende Mahngebühren</translation>
    </message>
    <message>
        <source>Login Failed: You have a recalled item which is overdue</source>
        <translation>Anmeldung fehlgeschlagen: Sie haben ein zurückgefordertes Medium, das überfällig ist</translation>
    </message>
    <message>
        <source>Login Failed: You have been billed for too many items</source>
        <translation>Anmeldung fehlgeschlagen: Ihnen wurden zu viele Medien in Rechnung gestellt</translation>
    </message>
    <message>
        <source>Login Failed: Client not registered</source>
        <translation>Anmeldung fehlgeschlagen: Gerät ist nicht registriert</translation>
    </message>
    <message>
        <source>Login Failed: Unable to connect to ILS</source>
        <translation>Anmeldung fehlgeschlagen: Verbindung zum Bibliothekssystem (ILS) nicht möglich</translation>
    </message>
    <message>
        <source>Login Failed: Too many concurrent sessions on this account</source>
        <translation>Anmeldung fehlgeschlagen: Zu viele gleichzeitige Sitzungen für dieses Konto</translation>
    </message>
    <message>
        <source>Login Failed: Expired Membership. Please inquire at the circulation desk.</source>
        <translation>Anmeldung fehlgeschlagen: Mitgliedschaft abgelaufen. Bitte wenden Sie sich an die Ausleihtheke.</translation>
    </message>
    <message>
        <source>Login Failed: </source>
        <translation>Anmeldung fehlgeschlagen: </translation>
    </message>
    <message>
        <source>Reserved: </source>
        <translation>Reserviert: </translation>
    </message>
    <message>
        <source>This kiosk is out of order.</source>
        <translation>Dieses Gerät ist außer Betrieb.</translation>
    </message>
    <message>
        <source>Error connecting to server. Verify Libki server is accessible from this network. Error Code: </source>
        <translation>Fehler beim Verbinden mit dem Server. Bitte prüfen Sie, ob der Libki-Server über dieses Netzwerk erreichbar ist. Fehlercode: </translation>
    </message>
    <message>
        <source>Error connecting to Internet: </source>
        <translation>Fehler beim Verbinden mit dem Internet: </translation>
    </message>
</context>
<context>
    <name>SessionLockedWindow</name>
    <message>
        <source>Libki Kiosk System</source>
        <translation>Libki Kiosk-System</translation>
    </message>
    <message>
        <source>Internet Kiosk</source>
        <translation>Internet-Terminal</translation>
    </message>
    <message>
        <source>about:blank</source>
        <translation></translation>
    </message>
    <message>
        <source>Session Locked</source>
        <translation>Sitzung gesperrt</translation>
    </message>
    <message>
        <source>Enter Password To Resume Session</source>
        <translation>Passwort eingeben, um die Sitzung fortzusetzen</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
    <message>
        <source>Resume</source>
        <translation>Fortsetzen</translation>
    </message>
    <message>
        <source>Incorrect Password</source>
        <translation>Falsches Passwort</translation>
    </message>
</context>
<context>
    <name>TimerWindow</name>
    <message>
        <source>Libki Kiosk System</source>
        <translation>Libki Kiosk-System</translation>
    </message>
    <message>
        <source>Log Out</source>
        <translation>Abmelden</translation>
    </message>
    <message>
        <source>Lock Session</source>
        <translation>Sitzung sperren</translation>
    </message>
    <message>
        <source>You have one or more items on hold waiting for pickup. Please contact a librarian for more details</source>
        <translation>Sie haben ein oder mehrere vorgemerkte Medien zur Abholung bereit. Bitte wenden Sie sich für weitere Informationen an das Bibliothekspersonal</translation>
    </message>
    <message>
        <source>Minutes Left</source>
        <translation>Minuten übrig</translation>
    </message>
    <message>
        <source>Log Out?</source>
        <translation>Abmelden?</translation>
    </message>
    <message>
        <source>Are you sure you want to log out?</source>
        <translation>Möchten Sie sich wirklich abmelden?</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Time Remaining</source>
        <translation>Verbleibende Zeit</translation>
    </message>
    <message>
        <source>Inactivity detected</source>
        <translation>Inaktivität erkannt</translation>
    </message>
    <message>
        <source>Please confirm you are still using this computer.</source>
        <translation>Bitte bestätigen Sie, dass Sie diesen Computer noch verwenden.</translation>
    </message>
    <message>
        <source>You have a message</source>
        <translation>Sie haben eine Nachricht</translation>
    </message>
</context>
</TS>
