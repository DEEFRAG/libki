/********************************************************************************
** Form generated from reading UI file 'timerwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TIMERWINDOW_H
#define UI_TIMERWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TimerWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QLabel *logo;
    QFrame *line;
    QVBoxLayout *verticalLayout;
    QLCDNumber *lcdNumber;
    QProgressBar *progressBar;
    QFrame *line_2;
    QGridLayout *gridLayout;
    QPushButton *logoutButton;
    QSpacerItem *verticalSpacer;
    QPushButton *lockSessionButton;
    QMenuBar *menubar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *TimerWindow)
    {
        if (TimerWindow->objectName().isEmpty())
            TimerWindow->setObjectName(QString::fromUtf8("TimerWindow"));
        TimerWindow->resize(690, 264);
        centralwidget = new QWidget(TimerWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        logo = new QLabel(centralwidget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setMaximumSize(QSize(150, 150));
        logo->setText(QString::fromUtf8(""));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/images/images/libki_clock.png")));
        logo->setScaledContents(true);

        horizontalLayout->addWidget(logo);

        line = new QFrame(centralwidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        horizontalLayout->addWidget(line);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lcdNumber = new QLCDNumber(centralwidget);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setSmallDecimalPoint(false);
        lcdNumber->setMode(QLCDNumber::Dec);
        lcdNumber->setSegmentStyle(QLCDNumber::Filled);
        lcdNumber->setProperty("value", QVariant(0.000000000000000));
        lcdNumber->setProperty("intValue", QVariant(0));

        verticalLayout->addWidget(lcdNumber);

        progressBar = new QProgressBar(centralwidget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(100);
        progressBar->setInvertedAppearance(false);

        verticalLayout->addWidget(progressBar);


        horizontalLayout->addLayout(verticalLayout);

        line_2 = new QFrame(centralwidget);
        line_2->setObjectName(QString::fromUtf8("line_2"));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        horizontalLayout->addWidget(line_2);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(20, 20, 20, 20);
        logoutButton = new QPushButton(centralwidget);
        logoutButton->setObjectName(QString::fromUtf8("logoutButton"));
        logoutButton->setMinimumSize(QSize(0, 0));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/images/icons/sign-out-alt-solid.svg"), QSize(), QIcon::Normal, QIcon::Off);
        logoutButton->setIcon(icon);
        logoutButton->setIconSize(QSize(48, 48));

        gridLayout->addWidget(logoutButton, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 1, 0, 1, 1);

        lockSessionButton = new QPushButton(centralwidget);
        lockSessionButton->setObjectName(QString::fromUtf8("lockSessionButton"));
        lockSessionButton->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lockSessionButton->sizePolicy().hasHeightForWidth());
        lockSessionButton->setSizePolicy(sizePolicy);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/icons/images/icons/lock-solid.svg"), QSize(), QIcon::Normal, QIcon::Off);
        lockSessionButton->setIcon(icon1);
        lockSessionButton->setIconSize(QSize(36, 36));

        gridLayout->addWidget(lockSessionButton, 2, 0, 1, 1);


        horizontalLayout->addLayout(gridLayout);

        TimerWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TimerWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 690, 21));
        TimerWindow->setMenuBar(menubar);
        statusBar = new QStatusBar(TimerWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        TimerWindow->setStatusBar(statusBar);

        retranslateUi(TimerWindow);

        QMetaObject::connectSlotsByName(TimerWindow);
    } // setupUi

    void retranslateUi(QMainWindow *TimerWindow)
    {
        TimerWindow->setWindowTitle(QCoreApplication::translate("TimerWindow", "Libki Kiosk System", nullptr));
        logoutButton->setText(QCoreApplication::translate("TimerWindow", "Log Out", nullptr));
        lockSessionButton->setText(QCoreApplication::translate("TimerWindow", "Lock Session", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TimerWindow: public Ui_TimerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TIMERWINDOW_H
