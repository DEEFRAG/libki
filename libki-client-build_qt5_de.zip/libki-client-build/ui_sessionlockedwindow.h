/********************************************************************************
** Form generated from reading UI file 'sessionlockedwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.13
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SESSIONLOCKEDWINDOW_H
#define UI_SESSIONLOCKEDWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWebKitWidgets/QWebView>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SessionLockedWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QSpacerItem *verticalSpacer;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QLabel *headerLabel;
    QHBoxLayout *logoWebViewLayout;
    QSpacerItem *horizontalSpacer_11;
    QWebView *logoWebView;
    QSpacerItem *horizontalSpacer_12;
    QLabel *logo;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *sessionLockedLabel;
    QLabel *errorLabel;
    QLabel *messageLabel;
    QSpacerItem *horizontalSpacer_4;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_5;
    QFormLayout *formLayout;
    QLabel *passwordLabel;
    QLineEdit *passwordField;
    QPushButton *resumeButton;
    QSpacerItem *horizontalSpacer_6;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_2;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_7;
    QSpacerItem *horizontalSpacer_7;
    QSpacerItem *horizontalSpacer_8;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_9;
    QSpacerItem *horizontalSpacer_10;
    QLabel *clientNameLabel;
    QMenuBar *menubar;

    void setupUi(QMainWindow *SessionLockedWindow)
    {
        if (SessionLockedWindow->objectName().isEmpty())
            SessionLockedWindow->setObjectName(QString::fromUtf8("SessionLockedWindow"));
        SessionLockedWindow->resize(857, 917);
        centralwidget = new QWidget(SessionLockedWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 2, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 3, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        headerLabel = new QLabel(centralwidget);
        headerLabel->setObjectName(QString::fromUtf8("headerLabel"));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        headerLabel->setFont(font);
        headerLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(headerLabel);

        logoWebViewLayout = new QHBoxLayout();
        logoWebViewLayout->setObjectName(QString::fromUtf8("logoWebViewLayout"));
        logoWebViewLayout->setContentsMargins(-1, 0, -1, -1);
        horizontalSpacer_11 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        logoWebViewLayout->addItem(horizontalSpacer_11);

        logoWebView = new QWebView(centralwidget);
        logoWebView->setObjectName(QString::fromUtf8("logoWebView"));
        logoWebView->setUrl(QUrl(QString::fromUtf8("about:blank")));

        logoWebViewLayout->addWidget(logoWebView);

        horizontalSpacer_12 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        logoWebViewLayout->addItem(horizontalSpacer_12);


        verticalLayout->addLayout(logoWebViewLayout);

        logo = new QLabel(centralwidget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/images/images/libki.png")));
        logo->setScaledContents(false);
        logo->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(logo);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        sessionLockedLabel = new QLabel(centralwidget);
        sessionLockedLabel->setObjectName(QString::fromUtf8("sessionLockedLabel"));
        sessionLockedLabel->setEnabled(true);
        QFont font1;
        font1.setFamily(QString::fromUtf8("Bitstream Charter"));
        font1.setPointSize(18);
        font1.setBold(true);
        font1.setWeight(75);
        sessionLockedLabel->setFont(font1);
        sessionLockedLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(sessionLockedLabel);

        errorLabel = new QLabel(centralwidget);
        errorLabel->setObjectName(QString::fromUtf8("errorLabel"));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        errorLabel->setFont(font2);
        errorLabel->setFrameShape(QFrame::NoFrame);
        errorLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(errorLabel);

        messageLabel = new QLabel(centralwidget);
        messageLabel->setObjectName(QString::fromUtf8("messageLabel"));
        messageLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(messageLabel);


        horizontalLayout->addLayout(verticalLayout_2);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(10, 10, 10, 10);
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_5);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        formLayout->setLabelAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        formLayout->setContentsMargins(20, 20, 20, 20);
        passwordLabel = new QLabel(centralwidget);
        passwordLabel->setObjectName(QString::fromUtf8("passwordLabel"));
        passwordLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        formLayout->setWidget(0, QFormLayout::LabelRole, passwordLabel);

        passwordField = new QLineEdit(centralwidget);
        passwordField->setObjectName(QString::fromUtf8("passwordField"));
        passwordField->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(0, QFormLayout::FieldRole, passwordField);

        resumeButton = new QPushButton(centralwidget);
        resumeButton->setObjectName(QString::fromUtf8("resumeButton"));
        QFont font3;
        font3.setPointSize(12);
        resumeButton->setFont(font3);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icons/images/icons/sign-in-alt-solid.svg"), QSize(), QIcon::Normal, QIcon::Off);
        resumeButton->setIcon(icon);
        resumeButton->setIconSize(QSize(36, 36));

        formLayout->setWidget(1, QFormLayout::FieldRole, resumeButton);


        horizontalLayout_4->addLayout(formLayout);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_6);


        verticalLayout->addLayout(horizontalLayout_4);


        gridLayout->addLayout(verticalLayout, 3, 1, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 3, 2, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_2, 5, 1, 1, 1);

        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));

        gridLayout->addWidget(widget, 4, 1, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_7);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer_8);


        gridLayout->addLayout(horizontalLayout_7, 6, 1, 1, 1);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_9);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_10);


        gridLayout->addLayout(horizontalLayout_8, 1, 1, 1, 1);

        clientNameLabel = new QLabel(centralwidget);
        clientNameLabel->setObjectName(QString::fromUtf8("clientNameLabel"));

        gridLayout->addWidget(clientNameLabel, 1, 2, 1, 1);

        SessionLockedWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(SessionLockedWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 857, 21));
        SessionLockedWindow->setMenuBar(menubar);
#if QT_CONFIG(shortcut)
        passwordLabel->setBuddy(passwordField);
#endif // QT_CONFIG(shortcut)
        QWidget::setTabOrder(passwordField, resumeButton);

        retranslateUi(SessionLockedWindow);
        QObject::connect(passwordField, SIGNAL(returnPressed()), resumeButton, SLOT(click()));

        QMetaObject::connectSlotsByName(SessionLockedWindow);
    } // setupUi

    void retranslateUi(QMainWindow *SessionLockedWindow)
    {
        SessionLockedWindow->setWindowTitle(QCoreApplication::translate("SessionLockedWindow", "Libki Kiosk System", nullptr));
        headerLabel->setText(QCoreApplication::translate("SessionLockedWindow", "Internet Kiosk", nullptr));
        logo->setText(QString());
        sessionLockedLabel->setText(QCoreApplication::translate("SessionLockedWindow", "Session Locked", nullptr));
        errorLabel->setText(QString());
        messageLabel->setText(QCoreApplication::translate("SessionLockedWindow", "Enter Password To Resume Session", nullptr));
        passwordLabel->setText(QCoreApplication::translate("SessionLockedWindow", "Password:", nullptr));
        resumeButton->setText(QCoreApplication::translate("SessionLockedWindow", "Resume", nullptr));
        clientNameLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SessionLockedWindow: public Ui_SessionLockedWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SESSIONLOCKEDWINDOW_H
